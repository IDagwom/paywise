import React, { useState } from 'react';
import { 
  ArrowLeft, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Eye, 
  Download, 
  Search, 
  Filter,
  RefreshCw,
  User,
  CreditCard,
  Calendar,
  FileText,
  Mail,
  Phone,
  MapPin
} from 'lucide-react';

interface RefundRequest {
  id: string;
  transactionId: string;
  customerName: string;
  customerEmail: string;
  originalAmount: number;
  refundAmount: number;
  reason: string;
  status: 'pending' | 'approved' | 'processing' | 'completed' | 'rejected';
  requestedAt: string;
  processedAt?: string;
  completedAt?: string;
  paymentMethod: string;
  orderId: string;
  notes?: string;
}

interface Transaction {
  id: string;
  amount: number;
  customerName: string;
  customerEmail: string;
  status: 'completed';
  date: string;
  paymentMethod: string;
  orderId: string;
  refundableAmount: number;
  refunds: RefundRequest[];
}

const Refunds: React.FC = () => {
  const [activeTab, setActiveTab] = useState('requests');
  const [selectedRefund, setSelectedRefund] = useState<RefundRequest | null>(null);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [showRefundModal, setShowRefundModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [walletBalance, setWalletBalance] = useState(125430.50);
  const [searchTerm, setSearchTerm] = useState('');

  const [refundRequests, setRefundRequests] = useState<RefundRequest[]>([
    {
      id: 'REF-001',
      transactionId: 'TXN-12345',
      customerName: 'Sarah Johnson',
      customerEmail: 'sarah@example.com',
      originalAmount: 20000,
      refundAmount: 5000,
      reason: 'Product damaged during shipping',
      status: 'pending',
      requestedAt: '2024-01-15T10:30:00',
      paymentMethod: 'Visa ****4242',
      orderId: 'ORD-789',
      notes: 'Customer provided photos of damaged item'
    },
    {
      id: 'REF-002',
      transactionId: 'TXN-12346',
      customerName: 'Mike Chen',
      customerEmail: 'mike@example.com',
      originalAmount: 15000,
      refundAmount: 15000,
      reason: 'Order cancelled by customer',
      status: 'processing',
      requestedAt: '2024-01-14T14:20:00',
      processedAt: '2024-01-14T15:45:00',
      paymentMethod: 'Mastercard ****8888',
      orderId: 'ORD-790'
    },
    {
      id: 'REF-003',
      transactionId: 'TXN-12347',
      customerName: 'Emma Wilson',
      customerEmail: 'emma@example.com',
      originalAmount: 8000,
      refundAmount: 3000,
      reason: 'Partial order fulfillment',
      status: 'completed',
      requestedAt: '2024-01-13T09:15:00',
      processedAt: '2024-01-13T10:30:00',
      completedAt: '2024-01-14T16:20:00',
      paymentMethod: 'PayPal',
      orderId: 'ORD-791'
    }
  ]);

  const [transactions] = useState<Transaction[]>([
    {
      id: 'TXN-12345',
      amount: 20000,
      customerName: 'Sarah Johnson',
      customerEmail: 'sarah@example.com',
      status: 'completed',
      date: '2024-01-10T14:30:00',
      paymentMethod: 'Visa ****4242',
      orderId: 'ORD-789',
      refundableAmount: 15000, // 20000 - 5000 (pending refund)
      refunds: []
    },
    {
      id: 'TXN-12348',
      amount: 25000,
      customerName: 'David Brown',
      customerEmail: 'david@example.com',
      status: 'completed',
      date: '2024-01-12T16:45:00',
      paymentMethod: 'Visa ****1234',
      orderId: 'ORD-792',
      refundableAmount: 25000,
      refunds: []
    }
  ]);

  const [newRefund, setNewRefund] = useState({
    transactionId: '',
    refundAmount: 0,
    reason: '',
    notes: ''
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-NG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400';
      case 'processing':
        return 'bg-blue-500/20 text-blue-400';
      case 'approved':
        return 'bg-purple-500/20 text-purple-400';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'rejected':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'processing':
        return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-purple-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const approveRefund = (refundId: string) => {
    setRefundRequests(prev => prev.map(refund => {
      if (refund.id === refundId) {
        // Deduct from wallet
        setWalletBalance(current => current - refund.refundAmount);
        
        return {
          ...refund,
          status: 'processing' as const,
          processedAt: new Date().toISOString()
        };
      }
      return refund;
    }));

    // Simulate processing time (3 seconds) then complete
    setTimeout(() => {
      setRefundRequests(prev => prev.map(refund => {
        if (refund.id === refundId) {
          return {
            ...refund,
            status: 'completed' as const,
            completedAt: new Date().toISOString()
          };
        }
        return refund;
      }));
    }, 3000);

    alert('Refund approved! ₦' + refundRequests.find(r => r.id === refundId)?.refundAmount.toLocaleString() + ' has been deducted from your wallet. Customer will receive refund within 1 business day.');
  };

  const rejectRefund = (refundId: string) => {
    setRefundRequests(prev => prev.map(refund => {
      if (refund.id === refundId) {
        return {
          ...refund,
          status: 'rejected' as const,
          processedAt: new Date().toISOString()
        };
      }
      return refund;
    }));
  };

  const createRefund = () => {
    const transaction = transactions.find(t => t.id === newRefund.transactionId);
    if (!transaction) return;

    const refund: RefundRequest = {
      id: `REF-${String(refundRequests.length + 1).padStart(3, '0')}`,
      transactionId: newRefund.transactionId,
      customerName: transaction.customerName,
      customerEmail: transaction.customerEmail,
      originalAmount: transaction.amount,
      refundAmount: newRefund.refundAmount,
      reason: newRefund.reason,
      status: 'pending',
      requestedAt: new Date().toISOString(),
      paymentMethod: transaction.paymentMethod,
      orderId: transaction.orderId,
      notes: newRefund.notes
    };

    setRefundRequests(prev => [refund, ...prev]);
    setNewRefund({ transactionId: '', refundAmount: 0, reason: '', notes: '' });
    setShowRefundModal(false);
  };

  const renderRefundRequests = () => (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-1 gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search refunds..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
            />
          </div>
          <select className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            Filter
          </button>
          <button
            onClick={() => setShowRefundModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
          >
            <DollarSign className="w-4 h-4" />
            Create Refund
          </button>
        </div>
      </div>

      {/* Refund Requests Table */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Refund ID</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Customer</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Reason</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Requested</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {refundRequests.map((refund) => (
                <tr key={refund.id} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-white">{refund.id}</p>
                      <p className="text-xs text-gray-400">{refund.transactionId}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm text-white">{refund.customerName}</p>
                      <p className="text-xs text-gray-400">{refund.customerEmail}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-white">{formatCurrency(refund.refundAmount)}</p>
                      <p className="text-xs text-gray-400">of {formatCurrency(refund.originalAmount)}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-300 max-w-xs truncate">{refund.reason}</td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-1">
                      {getStatusIcon(refund.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(refund.status)}`}>
                        {refund.status}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-400">{formatDateTime(refund.requestedAt)}</td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setSelectedRefund(refund);
                          setShowTransactionModal(true);
                        }}
                        className="p-1 text-gray-400 hover:text-blue-400 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {refund.status === 'pending' && (
                        <>
                          <button
                            onClick={() => approveRefund(refund.id)}
                            className="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-xs text-white transition-colors"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => rejectRefund(refund.id)}
                            className="px-3 py-1 bg-red-600 hover:bg-red-700 rounded text-xs text-white transition-colors"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderTransactions = () => (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Refundable Transactions</h3>
          <p className="text-sm text-gray-400">Select a transaction to process a refund</p>
        </div>
        
        <div className="divide-y divide-gray-700">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-full">
                    <CreditCard className="w-6 h-6 text-gray-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{transaction.id}</p>
                    <p className="text-sm text-gray-400">{transaction.customerName}</p>
                    <p className="text-xs text-gray-500">{formatDateTime(transaction.date)}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">{formatCurrency(transaction.amount)}</p>
                    <p className="text-xs text-gray-400">Refundable: {formatCurrency(transaction.refundableAmount)}</p>
                  </div>
                  <button
                    onClick={() => {
                      setNewRefund(prev => ({ ...prev, transactionId: transaction.id }));
                      setShowRefundModal(true);
                    }}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs text-white transition-colors"
                  >
                    Refund
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Refund Management</h2>
          <p className="text-gray-400">Process customer refunds and manage requests</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm text-gray-400">Wallet Balance</p>
            <p className="text-lg font-bold text-white">{formatCurrency(walletBalance)}</p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Pending Requests</p>
              <p className="text-2xl font-bold text-white">
                {refundRequests.filter(r => r.status === 'pending').length}
              </p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <Clock className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Processing</p>
              <p className="text-2xl font-bold text-white">
                {refundRequests.filter(r => r.status === 'processing').length}
              </p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <RefreshCw className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Completed Today</p>
              <p className="text-2xl font-bold text-white">
                {refundRequests.filter(r => r.status === 'completed').length}
              </p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Refunded</p>
              <p className="text-2xl font-bold text-white">
                {formatCurrency(refundRequests.filter(r => r.status === 'completed').reduce((sum, r) => sum + r.refundAmount, 0))}
              </p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
        {[
          { id: 'requests', name: 'Refund Requests' },
          { id: 'transactions', name: 'Refundable Transactions' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'requests' && renderRefundRequests()}
      {activeTab === 'transactions' && renderTransactions()}

      {/* Create Refund Modal */}
      {showRefundModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold text-white mb-4">Create Refund</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Transaction ID</label>
                <select
                  value={newRefund.transactionId}
                  onChange={(e) => setNewRefund(prev => ({ ...prev, transactionId: e.target.value }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">Select Transaction</option>
                  {transactions.map(transaction => (
                    <option key={transaction.id} value={transaction.id}>
                      {transaction.id} - {transaction.customerName} - {formatCurrency(transaction.amount)}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Refund Amount (₦)</label>
                <input
                  type="number"
                  value={newRefund.refundAmount}
                  onChange={(e) => setNewRefund(prev => ({ ...prev, refundAmount: Number(e.target.value) }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="5000"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Reason</label>
                <select
                  value={newRefund.reason}
                  onChange={(e) => setNewRefund(prev => ({ ...prev, reason: e.target.value }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">Select Reason</option>
                  <option value="Product damaged during shipping">Product damaged during shipping</option>
                  <option value="Order cancelled by customer">Order cancelled by customer</option>
                  <option value="Partial order fulfillment">Partial order fulfillment</option>
                  <option value="Product not as described">Product not as described</option>
                  <option value="Customer changed mind">Customer changed mind</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Notes (Optional)</label>
                <textarea
                  value={newRefund.notes}
                  onChange={(e) => setNewRefund(prev => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="Additional notes..."
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowRefundModal(false)}
                className="flex-1 px-4 py-2 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={createRefund}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                Create Refund
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Refund Details Modal */}
      {showTransactionModal && selectedRefund && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">Refund Details</h3>
              <button
                onClick={() => setShowTransactionModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>
            
            <div className="space-y-6">
              {/* Refund Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400">Refund ID</label>
                    <p className="text-white font-medium">{selectedRefund.id}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Transaction ID</label>
                    <p className="text-white font-medium">{selectedRefund.transactionId}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Order ID</label>
                    <p className="text-white font-medium">{selectedRefund.orderId}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400">Status</label>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(selectedRefund.status)}
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(selectedRefund.status)}`}>
                        {selectedRefund.status}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Payment Method</label>
                    <p className="text-white font-medium">{selectedRefund.paymentMethod}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Requested</label>
                    <p className="text-white font-medium">{formatDateTime(selectedRefund.requestedAt)}</p>
                  </div>
                </div>
              </div>

              {/* Customer Information */}
              <div className="border-t border-gray-700 pt-6">
                <h4 className="text-white font-medium mb-4">Customer Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-400">Name</label>
                    <p className="text-white">{selectedRefund.customerName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Email</label>
                    <p className="text-white">{selectedRefund.customerEmail}</p>
                  </div>
                </div>
              </div>

              {/* Amount Information */}
              <div className="border-t border-gray-700 pt-6">
                <h4 className="text-white font-medium mb-4">Amount Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm text-gray-400">Original Amount</label>
                    <p className="text-white font-medium">{formatCurrency(selectedRefund.originalAmount)}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Refund Amount</label>
                    <p className="text-green-400 font-medium">{formatCurrency(selectedRefund.refundAmount)}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Remaining</label>
                    <p className="text-white font-medium">{formatCurrency(selectedRefund.originalAmount - selectedRefund.refundAmount)}</p>
                  </div>
                </div>
              </div>

              {/* Reason and Notes */}
              <div className="border-t border-gray-700 pt-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400">Reason</label>
                    <p className="text-white">{selectedRefund.reason}</p>
                  </div>
                  {selectedRefund.notes && (
                    <div>
                      <label className="text-sm text-gray-400">Notes</label>
                      <p className="text-white">{selectedRefund.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Timeline */}
              {selectedRefund.status !== 'pending' && (
                <div className="border-t border-gray-700 pt-6">
                  <h4 className="text-white font-medium mb-4">Timeline</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <div>
                        <p className="text-sm text-white">Refund Requested</p>
                        <p className="text-xs text-gray-400">{formatDateTime(selectedRefund.requestedAt)}</p>
                      </div>
                    </div>
                    {selectedRefund.processedAt && (
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div>
                          <p className="text-sm text-white">Refund Approved & Processing</p>
                          <p className="text-xs text-gray-400">{formatDateTime(selectedRefund.processedAt)}</p>
                        </div>
                      </div>
                    )}
                    {selectedRefund.completedAt && (
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <p className="text-sm text-white">Refund Completed</p>
                          <p className="text-xs text-gray-400">{formatDateTime(selectedRefund.completedAt)}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Actions */}
              {selectedRefund.status === 'pending' && (
                <div className="border-t border-gray-700 pt-6 flex gap-3">
                  <button
                    onClick={() => {
                      approveRefund(selectedRefund.id);
                      setShowTransactionModal(false);
                    }}
                    className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                  >
                    Approve Refund
                  </button>
                  <button
                    onClick={() => {
                      rejectRefund(selectedRefund.id);
                      setShowTransactionModal(false);
                    }}
                    className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                  >
                    Reject Refund
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Business Scenario Success Banner */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-green-500/20 rounded-lg">
            <CheckCircle className="w-6 h-6 text-green-400" />
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-green-400 mb-2">Partial Refund Success</h4>
            <p className="text-sm text-gray-300 mb-3">
              Customer completed ₦20,000 payment → Partial refund of ₦5,000 approved → 
              Amount deducted from merchant wallet → Customer receives refund within 1 business day
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Payment Completed</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Refund Approved</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Wallet Deducted</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-yellow-400" />
                <span>Customer Refund Processing</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Refunds;