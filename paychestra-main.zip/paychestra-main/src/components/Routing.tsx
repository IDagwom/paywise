import React, { useState } from 'react';
import { Plus, Edit, Trash2, Globe, TrendingUp, Settings } from 'lucide-react';

const Routing: React.FC = () => {
  const [rules, setRules] = useState([
    {
      id: 1,
      name: 'US High Value',
      priority: 1,
      conditions: [
        { type: 'country', operator: 'equals', value: 'US' },
        { type: 'amount', operator: 'greater_than', value: '1000' }
      ],
      providers: [
        { name: 'Stripe', percentage: 70 },
        { name: 'Adyen', percentage: 30 }
      ],
      status: 'active',
      transactions: 1245,
      successRate: 98.7
    },
    {
      id: 2,
      name: 'EU Standard',
      priority: 2,
      conditions: [
        { type: 'country', operator: 'in', value: 'EU' },
        { type: 'amount', operator: 'less_than', value: '500' }
      ],
      providers: [
        { name: 'Adyen', percentage: 80 },
        { name: 'PayPal', percentage: 20 }
      ],
      status: 'active',
      transactions: 2100,
      successRate: 97.2
    },
    {
      id: 3,
      name: 'Global Fallback',
      priority: 3,
      conditions: [
        { type: 'default', operator: 'equals', value: 'true' }
      ],
      providers: [
        { name: 'PayPal', percentage: 100 }
      ],
      status: 'active',
      transactions: 890,
      successRate: 96.8
    }
  ]);

  const getStatusColor = (status: string) => {
    return status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400';
  };

  const getConditionText = (condition: any) => {
    const operatorMap: { [key: string]: string } = {
      'equals': '=',
      'greater_than': '>',
      'less_than': '<',
      'in': 'in'
    };
    
    return `${condition.type} ${operatorMap[condition.operator]} ${condition.value}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Payment Routing</h2>
          <p className="text-gray-400">Configure intelligent payment routing rules</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <Plus className="w-4 h-4" />
          Add Rule
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Rules</p>
              <p className="text-2xl font-bold text-white">3</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Settings className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Avg Success Rate</p>
              <p className="text-2xl font-bold text-white">97.6%</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Transactions</p>
              <p className="text-2xl font-bold text-white">4,235</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <Globe className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Cost Savings</p>
              <p className="text-2xl font-bold text-white">$12.4K</p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Routing Rules */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Routing Rules</h3>
          <p className="text-sm text-gray-400 mt-1">Rules are processed in order of priority</p>
        </div>
        
        <div className="divide-y divide-gray-700">
          {rules.map((rule) => (
            <div key={rule.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-blue-400">#{rule.priority}</span>
                      <h4 className="text-lg font-medium text-white">{rule.name}</h4>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(rule.status)}`}>
                      {rule.status}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h5 className="text-sm font-medium text-gray-300 mb-2">Conditions</h5>
                      <div className="space-y-1">
                        {rule.conditions.map((condition, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <span className="text-sm text-gray-400">•</span>
                            <span className="text-sm text-gray-300">{getConditionText(condition)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h5 className="text-sm font-medium text-gray-300 mb-2">Provider Distribution</h5>
                      <div className="space-y-2">
                        {rule.providers.map((provider, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <span className="text-sm text-gray-300">{provider.name}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-blue-500 rounded-full"
                                  style={{ width: `${provider.percentage}%` }}
                                />
                              </div>
                              <span className="text-sm text-gray-400">{provider.percentage}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 mt-4 pt-4 border-t border-gray-700">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-400">Transactions:</span>
                      <span className="text-sm font-medium text-white">{rule.transactions.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-400">Success Rate:</span>
                      <span className="text-sm font-medium text-green-400">{rule.successRate}%</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 ml-4">
                  <button className="p-2 text-gray-400 hover:text-blue-400 transition-colors">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-red-400 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Route Testing */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Test Route</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Amount</label>
            <input 
              type="number" 
              placeholder="1000"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Country</label>
            <select className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500">
              <option>US</option>
              <option>UK</option>
              <option>DE</option>
              <option>CA</option>
            </select>
          </div>
          <div className="flex items-end">
            <button className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
              Test Route
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Routing;