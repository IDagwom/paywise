import React, { useState } from 'react';
import { DollarSign, CheckCircle, XCircle, AlertTriangle, Download, Upload, RefreshCw } from 'lucide-react';

const Reconciliation: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const reconciliationData = [
    {
      id: 1,
      date: '2024-01-15',
      provider: 'Stripe',
      expectedAmount: '$15,234.56',
      actualAmount: '$15,234.56',
      difference: '$0.00',
      status: 'matched',
      transactions: 123
    },
    {
      id: 2,
      date: '2024-01-15',
      provider: 'PayPal',
      expectedAmount: '$8,765.43',
      actualAmount: '$8,750.43',
      difference: '-$15.00',
      status: 'discrepancy',
      transactions: 87
    },
    {
      id: 3,
      date: '2024-01-15',
      provider: 'Adyen',
      expectedAmount: '$12,345.67',
      actualAmount: '$12,345.67',
      difference: '$0.00',
      status: 'matched',
      transactions: 156
    },
    {
      id: 4,
      date: '2024-01-14',
      provider: 'Square',
      expectedAmount: '$5,432.10',
      actualAmount: '$5,432.10',
      difference: '$0.00',
      status: 'matched',
      transactions: 67
    }
  ];

  const discrepancies = [
    {
      id: 1,
      transactionId: 'TX-12345',
      provider: 'PayPal',
      expectedAmount: '$123.45',
      actualAmount: '$120.45',
      difference: '-$3.00',
      reason: 'Fee discrepancy',
      status: 'investigating'
    },
    {
      id: 2,
      transactionId: 'TX-12346',
      provider: 'PayPal',
      expectedAmount: '$67.89',
      actualAmount: '$55.89',
      difference: '-$12.00',
      reason: 'Refund not recorded',
      status: 'resolved'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'matched':
        return 'bg-green-500/20 text-green-400';
      case 'discrepancy':
        return 'bg-red-500/20 text-red-400';
      case 'investigating':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'resolved':
        return 'bg-blue-500/20 text-blue-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getDifferenceColor = (difference: string) => {
    if (difference === '$0.00') return 'text-green-400';
    return difference.startsWith('-') ? 'text-red-400' : 'text-blue-400';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Reconciliation</h2>
          <p className="text-gray-400">Automated transaction matching and settlement verification</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
            <Upload className="w-4 h-4" />
            Import
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <RefreshCw className="w-4 h-4" />
            Reconcile
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Matched Today</p>
              <p className="text-2xl font-bold text-white">98.7%</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Discrepancies</p>
              <p className="text-2xl font-bold text-white">2</p>
            </div>
            <div className="p-3 bg-red-500/20 rounded-lg">
              <XCircle className="w-6 h-6 text-red-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Volume</p>
              <p className="text-2xl font-bold text-white">$41.8K</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Under Review</p>
              <p className="text-2xl font-bold text-white">1</p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'overview'
              ? 'bg-blue-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('discrepancies')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'discrepancies'
              ? 'bg-blue-600 text-white'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Discrepancies
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' ? (
        <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-lg font-semibold text-white">Daily Reconciliation</h3>
            <p className="text-sm text-gray-400 mt-1">Settlement matching by provider</p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-700/50">
                <tr>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Date</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Provider</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Expected</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actual</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Difference</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Status</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Transactions</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody>
                {reconciliationData.map((item) => (
                  <tr key={item.id} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                    <td className="py-4 px-6 text-sm text-gray-300">{item.date}</td>
                    <td className="py-4 px-6 text-sm font-medium text-white">{item.provider}</td>
                    <td className="py-4 px-6 text-sm text-gray-300">{item.expectedAmount}</td>
                    <td className="py-4 px-6 text-sm text-gray-300">{item.actualAmount}</td>
                    <td className="py-4 px-6">
                      <span className={`text-sm font-medium ${getDifferenceColor(item.difference)}`}>
                        {item.difference}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-sm text-gray-300">{item.transactions}</td>
                    <td className="py-4 px-6">
                      <button className="p-1 text-gray-400 hover:text-blue-400 transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
          <div className="p-6 border-b border-gray-700">
            <h3 className="text-lg font-semibold text-white">Discrepancies</h3>
            <p className="text-sm text-gray-400 mt-1">Transactions requiring attention</p>
          </div>
          
          <div className="divide-y divide-gray-700">
            {discrepancies.map((item) => (
              <div key={item.id} className="p-6 hover:bg-gray-700/30 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-sm font-medium text-white">{item.transactionId}</span>
                      <span className="text-sm text-gray-400">{item.provider}</span>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Expected: </span>
                        <span className="text-white">{item.expectedAmount}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Actual: </span>
                        <span className="text-white">{item.actualAmount}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Difference: </span>
                        <span className={getDifferenceColor(item.difference)}>{item.difference}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 mt-2">{item.reason}</p>
                  </div>
                  <div className="flex gap-2 ml-4">
                    <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs text-white transition-colors">
                      Investigate
                    </button>
                    <button className="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-xs text-white transition-colors">
                      Resolve
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Reconciliation;