import React, { useState } from 'react';
import { Search, Filter, Download, Eye, RefreshCw } from 'lucide-react';

const Transactions: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const transactions = [
    {
      id: 'TX-001234',
      amount: '$1,234.56',
      currency: 'USD',
      status: 'completed',
      customer: 'john@example.com',
      provider: 'Stripe',
      country: 'US',
      timestamp: '2024-01-15 14:30:22',
      method: 'Credit Card',
      reference: 'REF-9876'
    },
    {
      id: 'TX-001235',
      amount: '$987.65',
      currency: 'EUR',
      status: 'pending',
      customer: 'sarah@example.com',
      provider: 'PayPal',
      country: 'DE',
      timestamp: '2024-01-15 14:25:11',
      method: 'PayPal',
      reference: 'REF-9877'
    },
    {
      id: 'TX-001236',
      amount: '$543.21',
      currency: 'GBP',
      status: 'failed',
      customer: 'mike@example.com',
      provider: 'Adyen',
      country: 'UK',
      timestamp: '2024-01-15 14:20:05',
      method: 'Bank Transfer',
      reference: 'REF-9878'
    },
    {
      id: 'TX-001237',
      amount: '$2,345.67',
      currency: 'USD',
      status: 'completed',
      customer: 'anna@example.com',
      provider: 'Square',
      country: 'CA',
      timestamp: '2024-01-15 14:15:33',
      method: 'Debit Card',
      reference: 'REF-9879'
    },
    {
      id: 'TX-001238',
      amount: '$876.54',
      currency: 'AUD',
      status: 'refunded',
      customer: 'david@example.com',
      provider: 'Stripe',
      country: 'AU',
      timestamp: '2024-01-15 14:10:18',
      method: 'Credit Card',
      reference: 'REF-9880'
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      case 'refunded':
        return 'bg-blue-500/20 text-blue-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.reference.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-1 gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Transaction ID</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Customer</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Provider</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Country</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Timestamp</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction) => (
                <tr key={transaction.id} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                  <td className="py-4 px-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-white">{transaction.id}</span>
                      <span className="text-xs text-gray-400">{transaction.reference}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-white">{transaction.amount}</span>
                      <span className="text-xs text-gray-400">{transaction.currency}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(transaction.status)}`}>
                      {transaction.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-300">{transaction.customer}</td>
                  <td className="py-4 px-6 text-sm text-gray-300">{transaction.provider}</td>
                  <td className="py-4 px-6 text-sm text-gray-300">{transaction.country}</td>
                  <td className="py-4 px-6 text-sm text-gray-300">{transaction.timestamp}</td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button className="p-1 text-gray-400 hover:text-blue-400 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-green-400 transition-colors">
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-400">
          Showing {filteredTransactions.length} of {transactions.length} transactions
        </p>
        <div className="flex gap-2">
          <button className="px-3 py-1 bg-gray-800 border border-gray-700 rounded text-sm text-white hover:bg-gray-700 transition-colors">
            Previous
          </button>
          <button className="px-3 py-1 bg-blue-600 rounded text-sm text-white">1</button>
          <button className="px-3 py-1 bg-gray-800 border border-gray-700 rounded text-sm text-white hover:bg-gray-700 transition-colors">
            2
          </button>
          <button className="px-3 py-1 bg-gray-800 border border-gray-700 rounded text-sm text-white hover:bg-gray-700 transition-colors">
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default Transactions;