import React, { useState } from 'react';
import { 
  CreditCard, 
  TrendingUp, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  Eye,
  Download,
  Plus,
  Settings,
  Bell,
  HelpCircle,
  Wallet,
  Shield,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  Smartphone,
  Search,
  Filter
} from 'lucide-react';

interface IndividualDashboardProps {
  activeSection?: string;
}

const IndividualDashboard: React.FC<IndividualDashboardProps> = ({ activeSection = 'dashboard' }) => {
  const [timeRange, setTimeRange] = useState('30d');
  const [searchTerm, setSearchTerm] = useState('');

  // Sample data for individual user
  const userStats = {
    totalSpent: 2847.50,
    transactions: 47,
    savedCards: 3,
    avgTransaction: 60.59
  };

  const monthlySpending = [
    { month: 'Jan', amount: 245 },
    { month: 'Feb', amount: 189 },
    { month: 'Mar', amount: 267 },
    { month: 'Apr', amount: 198 },
    { month: 'May', amount: 334 },
    { month: 'Jun', amount: 289 },
    { month: 'Jul', amount: 356 },
    { month: 'Aug', amount: 298 },
    { month: 'Sep', amount: 267 },
    { month: 'Oct', amount: 234 },
    { month: 'Nov', amount: 289 },
    { month: 'Dec', amount: 381 }
  ];

  const recentTransactions = [
    {
      id: 'TXN-001',
      merchant: 'Amazon',
      amount: 89.99,
      status: 'completed',
      date: '2024-01-15',
      category: 'Shopping',
      method: 'Visa ****4242'
    },
    {
      id: 'TXN-002',
      merchant: 'Starbucks',
      amount: 12.50,
      status: 'completed',
      date: '2024-01-15',
      category: 'Food & Drink',
      method: 'Apple Pay'
    },
    {
      id: 'TXN-003',
      merchant: 'Netflix',
      amount: 15.99,
      status: 'completed',
      date: '2024-01-14',
      category: 'Entertainment',
      method: 'Visa ****4242'
    },
    {
      id: 'TXN-004',
      merchant: 'Uber',
      amount: 24.75,
      status: 'pending',
      date: '2024-01-14',
      category: 'Transportation',
      method: 'Mastercard ****8888'
    },
    {
      id: 'TXN-005',
      merchant: 'Target',
      amount: 156.30,
      status: 'completed',
      date: '2024-01-13',
      category: 'Shopping',
      method: 'Debit Card ****1234'
    }
  ];

  const savedCards = [
    {
      id: 1,
      type: 'Visa',
      last4: '4242',
      expiry: '12/26',
      isDefault: true,
      nickname: 'Personal Card'
    },
    {
      id: 2,
      type: 'Mastercard',
      last4: '8888',
      expiry: '08/25',
      isDefault: false,
      nickname: 'Business Card'
    },
    {
      id: 3,
      type: 'American Express',
      last4: '1005',
      expiry: '03/27',
      isDefault: false,
      nickname: 'Travel Card'
    }
  ];

  const spendingByCategory = [
    { category: 'Shopping', amount: 1245.50, percentage: 44 },
    { category: 'Food & Drink', amount: 567.25, percentage: 20 },
    { category: 'Transportation', amount: 423.75, percentage: 15 },
    { category: 'Entertainment', amount: 334.50, percentage: 12 },
    { category: 'Bills & Utilities', amount: 276.50, percentage: 9 }
  ];

  const maxAmount = Math.max(...monthlySpending.map(d => d.amount));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Shopping': 'bg-blue-500',
      'Food & Drink': 'bg-green-500',
      'Transportation': 'bg-yellow-500',
      'Entertainment': 'bg-purple-500',
      'Bills & Utilities': 'bg-red-500'
    };
    return colors[category] || 'bg-gray-500';
  };

  const renderDashboardContent = () => (
    <>
      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-blue-400" />
            </div>
            <div className="flex items-center text-red-400 text-sm">
              <ArrowUpRight className="w-4 h-4" />
              <span>+8.2%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">${userStats.totalSpent.toLocaleString()}</p>
            <p className="text-sm text-gray-400">Total Spent (30d)</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <CreditCard className="w-6 h-6 text-green-400" />
            </div>
            <div className="flex items-center text-green-400 text-sm">
              <ArrowUpRight className="w-4 h-4" />
              <span>+12.5%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{userStats.transactions}</p>
            <p className="text-sm text-gray-400">Transactions</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Wallet className="w-6 h-6 text-purple-400" />
            </div>
            <div className="flex items-center text-gray-400 text-sm">
              <span>Stable</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{userStats.savedCards}</p>
            <p className="text-sm text-gray-400">Saved Cards</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-yellow-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-400" />
            </div>
            <div className="flex items-center text-red-400 text-sm">
              <ArrowDownRight className="w-4 h-4" />
              <span>-3.1%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">${userStats.avgTransaction.toFixed(2)}</p>
            <p className="text-sm text-gray-400">Avg Transaction</p>
          </div>
        </div>
      </div>

      {/* Spending Chart and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spending Chart */}
        <div className="lg:col-span-2 bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Monthly Spending</h3>
              <p className="text-sm text-gray-400">Your spending pattern over the year</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white">${userStats.totalSpent.toLocaleString()}</p>
              <p className="text-sm text-red-400">+8.2% vs last month</p>
            </div>
          </div>
          
          <div className="h-48 flex items-end justify-between space-x-1">
            {monthlySpending.map((month, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full bg-gray-700 rounded-t-sm relative overflow-hidden" style={{ height: '160px' }}>
                  <div
                    className="absolute bottom-0 w-full bg-blue-500 rounded-t-sm transition-all duration-1000 ease-out"
                    style={{
                      height: `${(month.amount / maxAmount) * 100}%`,
                      opacity: 0.8,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-400 mt-2">{month.month}</span>
                <span className="text-xs text-gray-500">${month.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full flex items-center gap-3 p-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
              <Plus className="w-5 h-5" />
              <span>Add Payment Method</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Download className="w-5 h-5" />
              <span>Download Statements</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Shield className="w-5 h-5" />
              <span>Security Settings</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Calendar className="w-5 h-5" />
              <span>Set Spending Limits</span>
            </button>
          </div>

          {/* Spending Insights */}
          <div className="mt-6 pt-6 border-t border-gray-700">
            <h4 className="text-sm font-medium text-gray-300 mb-3">This Month's Insights</h4>
            <div className="space-y-2">
              <div className="flex items-start gap-2 p-2 bg-green-500/10 border border-green-500/20 rounded text-xs">
                <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <span className="text-green-400">You're spending 12% less than last month!</span>
              </div>
              <div className="flex items-start gap-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-xs">
                <TrendingUp className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <span className="text-blue-400">Shopping is your top category this month</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions and Spending Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-gray-800 rounded-lg border border-gray-700">
          <div className="p-6 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-white">Recent Transactions</h3>
                <p className="text-sm text-gray-400">Your latest payment activity</p>
              </div>
              <button className="text-blue-400 hover:text-blue-300 text-sm font-medium">
                View all
              </button>
            </div>
          </div>
          
          <div className="divide-y divide-gray-700">
            {recentTransactions.slice(0, 5).map((transaction) => (
              <div key={transaction.id} className="p-4 hover:bg-gray-700/30 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 bg-gray-700 rounded-full">
                      <span className="text-sm font-medium text-white">
                        {transaction.merchant.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{transaction.merchant}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <span>{transaction.category}</span>
                        <span>•</span>
                        <span>{transaction.method}</span>
                        <span>•</span>
                        <span>{transaction.date}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-sm font-medium text-white">${transaction.amount}</p>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(transaction.status)}
                        <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                          {transaction.status}
                        </span>
                      </div>
                    </div>
                    <button className="p-1 text-gray-400 hover:text-white transition-colors">
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Spending by Category */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Spending by Category</h3>
          <div className="space-y-4">
            {spendingByCategory.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${getCategoryColor(item.category)}`}></div>
                  <span className="text-sm text-gray-300">{item.category}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-20 h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${getCategoryColor(item.category)}`}
                      style={{ width: `${item.percentage}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-400 w-12 text-right">{item.percentage}%</span>
                  <span className="text-sm font-medium text-white w-20 text-right">${item.amount.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Saved Payment Methods */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white">Saved Payment Methods</h3>
              <p className="text-sm text-gray-400">Manage your cards and payment options</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
              <Plus className="w-4 h-4" />
              Add Card
            </button>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {savedCards.map((card) => (
              <div key={card.id} className="relative bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg p-4 border border-gray-600">
                {card.isDefault && (
                  <div className="absolute top-2 right-2">
                    <span className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                      Default
                    </span>
                  </div>
                )}
                <div className="flex items-center justify-between mb-3">
                  <div className="text-sm font-medium text-white">{card.type}</div>
                  <div className="w-8 h-6 bg-gray-600 rounded flex items-center justify-center">
                    <span className="text-xs font-bold text-white">
                      {card.type.charAt(0)}
                    </span>
                  </div>
                </div>
                <div className="text-lg font-mono text-white mb-2">
                  •••• •••• •••• {card.last4}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">{card.nickname}</span>
                  <span className="text-gray-400">{card.expiry}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );

  const renderTransactionsContent = () => (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-1 gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
            />
          </div>
          <select className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500">
            <option value="all">All Categories</option>
            <option value="shopping">Shopping</option>
            <option value="food">Food & Drink</option>
            <option value="transport">Transportation</option>
            <option value="entertainment">Entertainment</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* All Transactions */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">All Transactions</h3>
          <p className="text-sm text-gray-400">Complete transaction history</p>
        </div>
        
        <div className="divide-y divide-gray-700">
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-full">
                    <span className="text-sm font-medium text-white">
                      {transaction.merchant.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{transaction.merchant}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <span>{transaction.id}</span>
                      <span>•</span>
                      <span>{transaction.category}</span>
                      <span>•</span>
                      <span>{transaction.method}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{transaction.date}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">${transaction.amount}</p>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(transaction.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                        {transaction.status}
                      </span>
                    </div>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-white transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPaymentMethodsContent = () => (
    <div className="space-y-6">
      {/* Add New Card */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-white">Payment Methods</h3>
            <p className="text-sm text-gray-400">Manage your saved cards and payment options</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Plus className="w-4 h-4" />
            Add New Card
          </button>
        </div>
      </div>

      {/* Saved Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {savedCards.map((card) => (
          <div key={card.id} className="relative bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg p-6 border border-gray-600">
            {card.isDefault && (
              <div className="absolute top-4 right-4">
                <span className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
                  Default
                </span>
              </div>
            )}
            <div className="flex items-center justify-between mb-4">
              <div className="text-lg font-medium text-white">{card.type}</div>
              <div className="w-10 h-8 bg-gray-600 rounded flex items-center justify-center">
                <span className="text-sm font-bold text-white">
                  {card.type.charAt(0)}
                </span>
              </div>
            </div>
            <div className="text-xl font-mono text-white mb-4">
              •••• •••• •••• {card.last4}
            </div>
            <div className="flex items-center justify-between text-sm mb-4">
              <span className="text-gray-400">{card.nickname}</span>
              <span className="text-gray-400">{card.expiry}</span>
            </div>
            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-gray-600 hover:bg-gray-500 rounded text-sm text-white transition-colors">
                Edit
              </button>
              <button className="flex-1 px-3 py-2 bg-red-600 hover:bg-red-700 rounded text-sm text-white transition-colors">
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSettingsContent = () => (
    <div className="space-y-6">
      {/* Profile Settings */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Profile Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
            <input 
              type="text" 
              defaultValue="Sarah Johnson"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
            <input 
              type="email" 
              defaultValue="sarah@example.com"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Security Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Two-Factor Authentication</p>
              <p className="text-xs text-gray-400">Add an extra layer of security</p>
            </div>
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white text-sm transition-colors">
              Enable
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Login Notifications</p>
              <p className="text-xs text-gray-400">Get notified of new logins</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Spending Limits */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Spending Limits</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Daily Limit</label>
            <input 
              type="number" 
              defaultValue="500"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Monthly Limit</label>
            <input 
              type="number" 
              defaultValue="5000"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    const currentUrl = window.location.hash || '#individual';
    
    if (currentUrl.includes('individual-transactions')) {
      return renderTransactionsContent();
    } else if (currentUrl.includes('individual-cards')) {
      return renderPaymentMethodsContent();
    } else if (currentUrl.includes('individual-settings')) {
      return renderSettingsContent();
    } else {
      return renderDashboardContent();
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Welcome back, Sarah! 👋</h1>
          <p className="text-gray-400">Here's your spending overview and recent activity</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 3 months</option>
            <option value="1y">Last year</option>
          </select>
          <button className="p-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
          </button>
          <button className="p-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400 hover:text-white transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {renderContent()}
    </div>
  );
};

export default IndividualDashboard;