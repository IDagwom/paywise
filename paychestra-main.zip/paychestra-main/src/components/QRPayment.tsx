import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  Download, 
  Copy, 
  Bell, 
  CheckCircle, 
  DollarSign,
  Smartphone,
  Wallet,
  Settings,
  RefreshCw,
  Eye,
  Share2,
  Printer
} from 'lucide-react';

interface Payment {
  id: string;
  amount: number;
  currency: string;
  customerPhone?: string;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
  reference: string;
}

interface QRCodeData {
  merchantId: string;
  walletAddress: string;
  businessName: string;
  qrCodeUrl: string;
}

const QRPayment: React.FC = () => {
  const [qrCode, setQrCode] = useState<QRCodeData | null>(null);
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);
  const [walletBalance, setWalletBalance] = useState(125430.50);
  const [notifications, setNotifications] = useState<Payment[]>([]);
  const [showNotification, setShowNotification] = useState(false);
  const [qrSettings, setQrSettings] = useState({
    staticAmount: false,
    defaultAmount: 0,
    description: '',
    expiryEnabled: false,
    expiryHours: 24
  });

  // Generate QR Code on component mount
  useEffect(() => {
    generateQRCode();
  }, []);

  // Simulate real-time payment notifications
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate random payments for demo
      if (Math.random() > 0.95) { // 5% chance every second
        simulatePayment();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const generateQRCode = () => {
    const merchantData: QRCodeData = {
      merchantId: 'MERCH_' + Date.now().toString().slice(-6),
      walletAddress: '0x' + Math.random().toString(16).substr(2, 40),
      businessName: "Alex's Coffee Shop",
      qrCodeUrl: `data:image/svg+xml;base64,${btoa(generateQRCodeSVG())}`
    };
    setQrCode(merchantData);
  };

  const generateQRCodeSVG = () => {
    // Simple QR code SVG representation
    return `
      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="white"/>
        <g fill="black">
          <!-- QR Code pattern simulation -->
          <rect x="10" y="10" width="20" height="20"/>
          <rect x="40" y="10" width="20" height="20"/>
          <rect x="70" y="10" width="20" height="20"/>
          <rect x="130" y="10" width="20" height="20"/>
          <rect x="160" y="10" width="20" height="20"/>
          <rect x="10" y="40" width="20" height="20"/>
          <rect x="70" y="40" width="20" height="20"/>
          <rect x="100" y="40" width="20" height="20"/>
          <rect x="160" y="40" width="20" height="20"/>
          <rect x="10" y="70" width="20" height="20"/>
          <rect x="40" y="70" width="20" height="20"/>
          <rect x="100" y="70" width="20" height="20"/>
          <rect x="130" y="70" width="20" height="20"/>
          <rect x="160" y="70" width="20" height="20"/>
          <rect x="40" y="100" width="20" height="20"/>
          <rect x="70" y="100" width="20" height="20"/>
          <rect x="130" y="100" width="20" height="20"/>
          <rect x="10" y="130" width="20" height="20"/>
          <rect x="70" y="130" width="20" height="20"/>
          <rect x="100" y="130" width="20" height="20"/>
          <rect x="160" y="130" width="20" height="20"/>
          <rect x="10" y="160" width="20" height="20"/>
          <rect x="40" y="160" width="20" height="20"/>
          <rect x="70" y="160" width="20" height="20"/>
          <rect x="130" y="160" width="20" height="20"/>
          <rect x="160" y="160" width="20" height="20"/>
        </g>
        <text x="100" y="190" text-anchor="middle" font-size="12" fill="black">Pay Alex's Coffee Shop</text>
      </svg>
    `;
  };

  const simulatePayment = () => {
    const amounts = [500, 1000, 1500, 2000, 2500, 5000, 7500, 10000];
    const amount = amounts[Math.random() * amounts.length | 0];
    
    const newPayment: Payment = {
      id: 'PAY_' + Date.now().toString(),
      amount: amount,
      currency: '₦',
      customerPhone: '+234' + Math.floor(Math.random() * 9000000000 + 1000000000),
      timestamp: new Date().toISOString(),
      status: 'completed',
      reference: 'QR_' + Math.random().toString(36).substr(2, 8).toUpperCase()
    };

    // Add to recent payments
    setRecentPayments(prev => [newPayment, ...prev.slice(0, 9)]);
    
    // Update wallet balance
    setWalletBalance(prev => prev + amount);
    
    // Show notification
    setNotifications(prev => [newPayment, ...prev.slice(0, 4)]);
    setShowNotification(true);
    
    // Hide notification after 5 seconds
    setTimeout(() => setShowNotification(false), 5000);
  };

  const copyQRCode = () => {
    if (qrCode) {
      navigator.clipboard.writeText(`Pay ${qrCode.businessName}: ${qrCode.walletAddress}`);
    }
  };

  const downloadQRCode = () => {
    if (qrCode) {
      const link = document.createElement('a');
      link.download = `${qrCode.businessName.replace(/\s+/g, '_')}_QR_Code.svg`;
      link.href = qrCode.qrCodeUrl;
      link.click();
    }
  };

  const shareQRCode = () => {
    if (navigator.share && qrCode) {
      navigator.share({
        title: `Pay ${qrCode.businessName}`,
        text: `Scan this QR code to pay ${qrCode.businessName}`,
        url: window.location.href
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Real-time Notification */}
      {showNotification && notifications.length > 0 && (
        <div className="fixed top-4 right-4 z-50 bg-green-500 text-white p-4 rounded-lg shadow-lg animate-slide-in-right">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6" />
            <div>
              <p className="font-semibold">Payment Received!</p>
              <p className="text-sm">₦{notifications[0].amount.toLocaleString()} from {notifications[0].customerPhone}</p>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">QR Code Payments</h2>
          <p className="text-gray-600 dark:text-gray-400">Accept instant payments via QR code scanning</p>
        </div>
        <button
          onClick={generateQRCode}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          Regenerate QR
        </button>
      </div>

      {/* Wallet Balance */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-green-100 text-sm">Merchant Wallet Balance</p>
            <p className="text-3xl font-bold">{formatCurrency(walletBalance)}</p>
            <p className="text-green-100 text-sm mt-1">Updates in real-time</p>
          </div>
          <div className="p-3 bg-white/20 rounded-lg">
            <Wallet className="w-8 h-8" />
          </div>
        </div>
      </div>

      {/* QR Code Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* QR Code Display */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Your Payment QR Code</h3>
          
          {qrCode && (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
                  <img 
                    src={qrCode.qrCodeUrl} 
                    alt="Payment QR Code" 
                    className="w-48 h-48"
                  />
                </div>
              </div>
              
              <div className="text-center space-y-2">
                <p className="font-medium text-gray-900 dark:text-white">{qrCode.businessName}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Merchant ID: {qrCode.merchantId}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500 font-mono break-all">
                  {qrCode.walletAddress}
                </p>
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={downloadQRCode}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download
                </button>
                <button
                  onClick={copyQRCode}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
                >
                  <Copy className="w-4 h-4" />
                  Copy
                </button>
                <button
                  onClick={shareQRCode}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
              </div>
            </div>
          )}
        </div>

        {/* QR Code Settings */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">QR Code Settings</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900 dark:text-white">Static Amount</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Set a fixed payment amount</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer" 
                  checked={qrSettings.staticAmount}
                  onChange={(e) => setQrSettings(prev => ({ ...prev, staticAmount: e.target.checked }))}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {qrSettings.staticAmount && (
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Default Amount (₦)
                </label>
                <input
                  type="number"
                  value={qrSettings.defaultAmount}
                  onChange={(e) => setQrSettings(prev => ({ ...prev, defaultAmount: Number(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="5000"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Payment Description
              </label>
              <input
                type="text"
                value={qrSettings.description}
                onChange={(e) => setQrSettings(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                placeholder="Coffee purchase"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900 dark:text-white">QR Code Expiry</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Auto-expire QR code</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer" 
                  checked={qrSettings.expiryEnabled}
                  onChange={(e) => setQrSettings(prev => ({ ...prev, expiryEnabled: e.target.checked }))}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {qrSettings.expiryEnabled && (
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Expiry Hours
                </label>
                <select
                  value={qrSettings.expiryHours}
                  onChange={(e) => setQrSettings(prev => ({ ...prev, expiryHours: Number(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value={1}>1 Hour</option>
                  <option value={6}>6 Hours</option>
                  <option value={12}>12 Hours</option>
                  <option value={24}>24 Hours</option>
                  <option value={72}>3 Days</option>
                </select>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent QR Payments */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent QR Payments</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Real-time payment notifications</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-green-600 dark:text-green-400">Live</span>
            </div>
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {recentPayments.length > 0 ? (
            recentPayments.map((payment) => (
              <div key={payment.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
                      <QrCode className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        QR Payment Received
                      </p>
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                        <span>{payment.customerPhone}</span>
                        <span>•</span>
                        <span>{formatTime(payment.timestamp)}</span>
                        <span>•</span>
                        <span className="text-green-600 dark:text-green-400">{payment.reference}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-lg font-semibold text-green-600 dark:text-green-400">
                      +₦{payment.amount.toLocaleString()}
                    </p>
                    <div className="flex items-center gap-1">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-green-600 dark:text-green-400">Instant</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-12 text-center">
              <QrCode className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No QR payments yet</p>
              <p className="text-sm text-gray-500 dark:text-gray-500">Share your QR code to start receiving payments</p>
            </div>
          )}
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
        <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-4">How QR Payments Work</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <QrCode className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">1. Display QR Code</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300">Show your QR code to customers at checkout</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Smartphone className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">2. Customer Scans</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300">Customer scans with their mobile banking app</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">3. Instant Payment</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300">Receive instant notification and funds</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRPayment;