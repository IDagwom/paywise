import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Clock, 
  DollarSign, 
  CheckCircle, 
  AlertTriangle, 
  Settings, 
  Plus, 
  Edit, 
  Trash2,
  Download,
  Mail,
  Calendar,
  TrendingUp,
  ArrowRight,
  Eye,
  RefreshCw
} from 'lucide-react';

interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  isDefault: boolean;
  isActive: boolean;
  addedDate: string;
}

interface SettlementRule {
  id: string;
  name: string;
  bankAccountId: string;
  minimumAmount: number;
  frequency: 'daily' | 'weekly' | 'monthly';
  time: string;
  isActive: boolean;
  currency: string;
}

interface SettlementTransaction {
  id: string;
  amount: number;
  bankAccount: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  initiatedAt: string;
  completedAt?: string;
  reference: string;
  fees: number;
  netAmount: number;
}

const Settlement: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [walletBalance, setWalletBalance] = useState(125430.50);
  const [showAddBank, setShowAddBank] = useState(false);
  const [showAddRule, setShowAddRule] = useState(false);

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([
    {
      id: '1',
      bankName: 'GTBank',
      accountNumber: '0123456789',
      accountName: "Alex's Coffee Shop",
      isDefault: true,
      isActive: true,
      addedDate: '2024-01-10'
    },
    {
      id: '2',
      bankName: 'First Bank',
      accountNumber: '2000123456',
      accountName: "Alex's Coffee Shop",
      isDefault: false,
      isActive: true,
      addedDate: '2024-01-15'
    }
  ]);

  const [settlementRules, setSettlementRules] = useState<SettlementRule[]>([
    {
      id: '1',
      name: 'Daily Auto-Settlement',
      bankAccountId: '1',
      minimumAmount: 10000,
      frequency: 'daily',
      time: '23:00',
      isActive: true,
      currency: 'NGN'
    }
  ]);

  const [settlementHistory, setSettlementHistory] = useState<SettlementTransaction[]>([
    {
      id: 'STL-001',
      amount: 45000,
      bankAccount: 'GTBank ****6789',
      status: 'completed',
      initiatedAt: '2024-01-15 23:00:00',
      completedAt: '2024-01-16 08:30:00',
      reference: 'STL20240115001',
      fees: 50,
      netAmount: 44950
    },
    {
      id: 'STL-002',
      amount: 32500,
      bankAccount: 'GTBank ****6789',
      status: 'completed',
      initiatedAt: '2024-01-14 23:00:00',
      completedAt: '2024-01-15 09:15:00',
      reference: 'STL20240114001',
      fees: 50,
      netAmount: 32450
    },
    {
      id: 'STL-003',
      amount: 28750,
      bankAccount: 'GTBank ****6789',
      status: 'processing',
      initiatedAt: '2024-01-16 23:00:00',
      reference: 'STL20240116001',
      fees: 50,
      netAmount: 28700
    }
  ]);

  const [newBankAccount, setNewBankAccount] = useState({
    bankName: '',
    accountNumber: '',
    accountName: ''
  });

  const [newRule, setNewRule] = useState({
    name: '',
    bankAccountId: '',
    minimumAmount: 10000,
    frequency: 'daily' as const,
    time: '23:00'
  });

  // Simulate daily settlement check
  useEffect(() => {
    const checkSettlement = () => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5);
      
      settlementRules.forEach(rule => {
        if (rule.isActive && rule.time === currentTime && walletBalance >= rule.minimumAmount) {
          // Simulate settlement
          const newSettlement: SettlementTransaction = {
            id: `STL-${Date.now()}`,
            amount: walletBalance,
            bankAccount: bankAccounts.find(acc => acc.id === rule.bankAccountId)?.bankName + ' ****' + 
                        bankAccounts.find(acc => acc.id === rule.bankAccountId)?.accountNumber.slice(-4) || '',
            status: 'processing',
            initiatedAt: now.toISOString(),
            reference: `STL${now.getFullYear()}${(now.getMonth()+1).toString().padStart(2,'0')}${now.getDate().toString().padStart(2,'0')}001`,
            fees: 50,
            netAmount: walletBalance - 50
          };
          
          setSettlementHistory(prev => [newSettlement, ...prev]);
          setWalletBalance(0); // Clear wallet after settlement
        }
      });
    };

    const interval = setInterval(checkSettlement, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [walletBalance, settlementRules, bankAccounts]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400';
      case 'processing':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'pending':
        return 'bg-blue-500/20 text-blue-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'processing':
        return <RefreshCw className="w-4 h-4 text-yellow-500 animate-spin" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-blue-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-NG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const addBankAccount = () => {
    if (newBankAccount.bankName && newBankAccount.accountNumber && newBankAccount.accountName) {
      const account: BankAccount = {
        id: Date.now().toString(),
        ...newBankAccount,
        isDefault: bankAccounts.length === 0,
        isActive: true,
        addedDate: new Date().toISOString().split('T')[0]
      };
      setBankAccounts(prev => [...prev, account]);
      setNewBankAccount({ bankName: '', accountNumber: '', accountName: '' });
      setShowAddBank(false);
    }
  };

  const addSettlementRule = () => {
    if (newRule.name && newRule.bankAccountId) {
      const rule: SettlementRule = {
        id: Date.now().toString(),
        ...newRule,
        isActive: true,
        currency: 'NGN'
      };
      setSettlementRules(prev => [...prev, rule]);
      setNewRule({
        name: '',
        bankAccountId: '',
        minimumAmount: 10000,
        frequency: 'daily',
        time: '23:00'
      });
      setShowAddRule(false);
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Wallet Balance & Next Settlement */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-blue-100 text-sm">Available Balance</p>
              <p className="text-3xl font-bold">{formatCurrency(walletBalance)}</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg">
              <DollarSign className="w-8 h-8" />
            </div>
          </div>
          <div className="flex items-center gap-2 text-blue-100 text-sm">
            <Clock className="w-4 h-4" />
            <span>Next settlement: Today at 11:00 PM</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Settlement Status</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {walletBalance >= 10000 ? 'Ready' : 'Pending'}
              </p>
            </div>
            <div className={`p-3 rounded-lg ${walletBalance >= 10000 ? 'bg-green-500/20' : 'bg-yellow-500/20'}`}>
              {walletBalance >= 10000 ? 
                <CheckCircle className="w-8 h-8 text-green-500" /> :
                <Clock className="w-8 h-8 text-yellow-500" />
              }
            </div>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {walletBalance >= 10000 
              ? 'Balance exceeds minimum threshold'
              : `Need ${formatCurrency(10000 - walletBalance)} more to trigger settlement`
            }
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">This Month</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">₦156K</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Settlements</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">12</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Calendar className="w-6 h-6 text-blue-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Fees</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">₦600</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-purple-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Success Rate</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">99.2%</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Settlements */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Settlements</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Latest automatic settlements</p>
            </div>
            <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm font-medium">
              View all
            </button>
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {settlementHistory.slice(0, 5).map((settlement) => (
            <div key={settlement.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-full">
                    <Building2 className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{settlement.bankAccount}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
                      <span>{settlement.reference}</span>
                      <span>•</span>
                      <span>{formatDateTime(settlement.initiatedAt)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{formatCurrency(settlement.netAmount)}</p>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(settlement.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(settlement.status)}`}>
                        {settlement.status}
                      </span>
                    </div>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderBankAccounts = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Bank Accounts</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">Manage your settlement bank accounts</p>
        </div>
        <button
          onClick={() => setShowAddBank(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Bank Account
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {bankAccounts.map((account) => (
          <div key={account.id} className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white">{account.bankName}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{account.accountName}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {account.isDefault && (
                  <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 text-xs rounded-full">
                    Default
                  </span>
                )}
                <span className={`px-2 py-1 text-xs rounded-full ${
                  account.isActive 
                    ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                }`}>
                  {account.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Account Number:</span>
                <span className="font-mono text-gray-900 dark:text-white">****{account.accountNumber.slice(-4)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Added:</span>
                <span className="text-gray-900 dark:text-white">{account.addedDate}</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button className="flex-1 px-3 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded text-sm text-gray-700 dark:text-gray-300 transition-colors">
                <Edit className="w-4 h-4 inline mr-1" />
                Edit
              </button>
              <button className="flex-1 px-3 py-2 bg-red-100 dark:bg-red-900/20 hover:bg-red-200 dark:hover:bg-red-900/30 rounded text-sm text-red-700 dark:text-red-400 transition-colors">
                <Trash2 className="w-4 h-4 inline mr-1" />
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Bank Account Modal */}
      {showAddBank && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Add Bank Account</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Bank Name
                </label>
                <select
                  value={newBankAccount.bankName}
                  onChange={(e) => setNewBankAccount(prev => ({ ...prev, bankName: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select Bank</option>
                  <option value="GTBank">GTBank</option>
                  <option value="First Bank">First Bank</option>
                  <option value="Access Bank">Access Bank</option>
                  <option value="Zenith Bank">Zenith Bank</option>
                  <option value="UBA">UBA</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Account Number
                </label>
                <input
                  type="text"
                  value={newBankAccount.accountNumber}
                  onChange={(e) => setNewBankAccount(prev => ({ ...prev, accountNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="0123456789"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Account Name
                </label>
                <input
                  type="text"
                  value={newBankAccount.accountName}
                  onChange={(e) => setNewBankAccount(prev => ({ ...prev, accountName: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Account holder name"
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddBank(false)}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={addBankAccount}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                Add Account
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderSettlementRules = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Settlement Rules</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">Configure automatic settlement preferences</p>
        </div>
        <button
          onClick={() => setShowAddRule(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Rule
        </button>
      </div>

      <div className="space-y-4">
        {settlementRules.map((rule) => {
          const bankAccount = bankAccounts.find(acc => acc.id === rule.bankAccountId);
          return (
            <div key={rule.id} className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-lg font-medium text-gray-900 dark:text-white">{rule.name}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      rule.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {rule.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Bank Account:</span>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {bankAccount?.bankName} ****{bankAccount?.accountNumber.slice(-4)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Minimum Amount:</span>
                      <p className="font-medium text-gray-900 dark:text-white">{formatCurrency(rule.minimumAmount)}</p>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Frequency:</span>
                      <p className="font-medium text-gray-900 dark:text-white capitalize">{rule.frequency}</p>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Time:</span>
                      <p className="font-medium text-gray-900 dark:text-white">{rule.time}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 ml-4">
                  <button className="p-2 text-gray-400 hover:text-blue-500 transition-colors">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Settlement Rule Modal */}
      {showAddRule && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Add Settlement Rule</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Rule Name
                </label>
                <input
                  type="text"
                  value={newRule.name}
                  onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Daily Auto-Settlement"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Bank Account
                </label>
                <select
                  value={newRule.bankAccountId}
                  onChange={(e) => setNewRule(prev => ({ ...prev, bankAccountId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="">Select Bank Account</option>
                  {bankAccounts.map(account => (
                    <option key={account.id} value={account.id}>
                      {account.bankName} ****{account.accountNumber.slice(-4)}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Minimum Amount (₦)
                </label>
                <input
                  type="number"
                  value={newRule.minimumAmount}
                  onChange={(e) => setNewRule(prev => ({ ...prev, minimumAmount: Number(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="10000"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Frequency
                  </label>
                  <select
                    value={newRule.frequency}
                    onChange={(e) => setNewRule(prev => ({ ...prev, frequency: e.target.value as 'daily' | 'weekly' | 'monthly' }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Time
                  </label>
                  <input
                    type="time"
                    value={newRule.time}
                    onChange={(e) => setNewRule(prev => ({ ...prev, time: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddRule(false)}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={addSettlementRule}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                Add Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderHistory = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Settlement History</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">Complete history of all settlements</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <Download className="w-4 h-4" />
          Export
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Reference</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Bank Account</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Fees</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Net Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Date</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {settlementHistory.map((settlement) => (
                <tr key={settlement.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                  <td className="py-4 px-6 text-sm font-medium text-gray-900 dark:text-white">{settlement.reference}</td>
                  <td className="py-4 px-6 text-sm text-gray-600 dark:text-gray-400">{settlement.bankAccount}</td>
                  <td className="py-4 px-6 text-sm text-gray-900 dark:text-white">{formatCurrency(settlement.amount)}</td>
                  <td className="py-4 px-6 text-sm text-gray-600 dark:text-gray-400">{formatCurrency(settlement.fees)}</td>
                  <td className="py-4 px-6 text-sm font-medium text-gray-900 dark:text-white">{formatCurrency(settlement.netAmount)}</td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-1">
                      {getStatusIcon(settlement.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(settlement.status)}`}>
                        {settlement.status}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-600 dark:text-gray-400">{formatDateTime(settlement.initiatedAt)}</td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button className="p-1 text-gray-400 hover:text-blue-500 transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-green-500 transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Settlement Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage automatic settlements to your bank accounts</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-gray-700 dark:text-gray-300 transition-colors">
            <Mail className="w-4 h-4" />
            Email Reports
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
        {[
          { id: 'overview', name: 'Overview' },
          { id: 'accounts', name: 'Bank Accounts' },
          { id: 'rules', name: 'Settlement Rules' },
          { id: 'history', name: 'History' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {tab.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'accounts' && renderBankAccounts()}
      {activeTab === 'rules' && renderSettlementRules()}
      {activeTab === 'history' && renderHistory()}

      {/* Settlement Info Banner */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
        <div className="flex items-start gap-4">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
            <CheckCircle className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Auto-Settlement Active</h4>
            <p className="text-sm text-blue-800 dark:text-blue-200 mb-3">
              Your daily auto-settlement to GTBank ****6789 is active. Funds will be transferred automatically 
              when your balance exceeds ₦10,000 at 11:00 PM daily.
            </p>
            <div className="flex items-center gap-4 text-sm text-blue-700 dark:text-blue-300">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>Next check: Today at 11:00 PM</span>
              </div>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                <span>Settlement fee: ₦50</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settlement;