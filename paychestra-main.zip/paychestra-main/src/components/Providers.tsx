import React, { useState } from 'react';
import { Plus, Edit, Trash2, Power, TrendingUp, AlertCircle } from 'lucide-react';

const Providers: React.FC = () => {
  const [providers, setProviders] = useState([
    {
      id: 1,
      name: 'Stripe',
      type: 'Card Processing',
      status: 'active',
      successRate: 98.7,
      volume: '$1.2M',
      fees: '2.9% + $0.30',
      regions: ['US', 'EU', 'UK', 'AU'],
      lastUpdated: '2024-01-15'
    },
    {
      id: 2,
      name: 'PayPal',
      type: 'Digital Wallet',
      status: 'active',
      successRate: 97.2,
      volume: '$890K',
      fees: '3.49% + $0.49',
      regions: ['Global'],
      lastUpdated: '2024-01-14'
    },
    {
      id: 3,
      name: 'Adyen',
      type: 'Card Processing',
      status: 'active',
      successRate: 98.9,
      volume: '$650K',
      fees: '2.6% + $0.10',
      regions: ['EU', 'APAC'],
      lastUpdated: '2024-01-13'
    },
    {
      id: 4,
      name: 'Square',
      type: 'Point of Sale',
      status: 'inactive',
      successRate: 96.8,
      volume: '$320K',
      fees: '2.6% + $0.10',
      regions: ['US', 'CA'],
      lastUpdated: '2024-01-10'
    }
  ]);

  const getStatusColor = (status: string) => {
    return status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400';
  };

  const getSuccessRateColor = (rate: number) => {
    if (rate >= 98) return 'text-green-400';
    if (rate >= 95) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Payment Providers</h2>
          <p className="text-gray-400">Manage your payment processor integrations</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <Plus className="w-4 h-4" />
          Add Provider
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Providers</p>
              <p className="text-2xl font-bold text-white">3</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <Power className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Average Success Rate</p>
              <p className="text-2xl font-bold text-white">98.3%</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Volume</p>
              <p className="text-2xl font-bold text-white">$2.76M</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Providers Table */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Provider</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Type</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Success Rate</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Volume</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Fees</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Regions</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {providers.map((provider) => (
                <tr key={provider.id} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center">
                        <span className="text-sm font-medium text-white">
                          {provider.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{provider.name}</p>
                        <p className="text-xs text-gray-400">Updated {provider.lastUpdated}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-300">{provider.type}</td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(provider.status)}`}>
                      {provider.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`text-sm font-medium ${getSuccessRateColor(provider.successRate)}`}>
                      {provider.successRate}%
                    </span>
                  </td>
                  <td className="py-4 px-6 text-sm font-medium text-white">{provider.volume}</td>
                  <td className="py-4 px-6 text-sm text-gray-300">{provider.fees}</td>
                  <td className="py-4 px-6">
                    <div className="flex gap-1">
                      {provider.regions.map((region, index) => (
                        <span key={index} className="px-2 py-1 bg-gray-700 rounded text-xs text-gray-300">
                          {region}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button className="p-1 text-gray-400 hover:text-blue-400 transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-yellow-400 transition-colors">
                        <Power className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-red-400 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Health Monitoring */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Provider Health Monitoring</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-700/50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span className="text-sm font-medium text-white">Latency Alert</span>
            </div>
            <p className="text-sm text-gray-400">PayPal response time increased by 15% in the last hour</p>
          </div>
          <div className="bg-gray-700/50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm font-medium text-white">All Systems Operational</span>
            </div>
            <p className="text-sm text-gray-400">All other providers are operating normally</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Providers;