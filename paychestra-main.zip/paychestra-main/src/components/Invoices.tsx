import React, { useState } from 'react';
import { 
  Plus, 
  Send, 
  Eye, 
  Download, 
  Edit, 
  Trash2, 
  Mail, 
  Link, 
  Calendar, 
  DollarSign,
  FileText,
  User,
  Building,
  Clock,
  CheckCircle,
  AlertTriangle,
  Copy,
  ExternalLink,
  Printer
} from 'lucide-react';

interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerEmail: string;
  customerAddress?: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';
  createdAt: string;
  dueDate: string;
  sentAt?: string;
  paidAt?: string;
  paymentLink: string;
  notes?: string;
}

const Invoices: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showCreateInvoice, setShowCreateInvoice] = useState(false);
  const [showInvoicePreview, setShowInvoicePreview] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const [invoices, setInvoices] = useState<Invoice[]>([
    {
      id: '1',
      invoiceNumber: 'INV-001',
      customerName: 'Sarah Johnson',
      customerEmail: 'sarah@example.com',
      customerAddress: '123 Lagos Street, Victoria Island, Lagos',
      items: [
        {
          id: '1',
          description: 'Website Development',
          quantity: 1,
          unitPrice: 250000,
          total: 250000
        },
        {
          id: '2',
          description: 'SEO Optimization',
          quantity: 3,
          unitPrice: 50000,
          total: 150000
        }
      ],
      subtotal: 400000,
      tax: 30000,
      total: 430000,
      status: 'paid',
      createdAt: '2024-01-10',
      dueDate: '2024-01-25',
      sentAt: '2024-01-10T10:30:00',
      paidAt: '2024-01-12T14:20:00',
      paymentLink: 'https://pay.payorchestra.com/inv/INV-001',
      notes: 'Thank you for your business!'
    },
    {
      id: '2',
      invoiceNumber: 'INV-002',
      customerName: 'Mike Chen',
      customerEmail: 'mike@techcorp.com',
      customerAddress: '456 Abuja Avenue, Wuse 2, Abuja',
      items: [
        {
          id: '1',
          description: 'Mobile App Development',
          quantity: 1,
          unitPrice: 500000,
          total: 500000
        }
      ],
      subtotal: 500000,
      tax: 37500,
      total: 537500,
      status: 'sent',
      createdAt: '2024-01-15',
      dueDate: '2024-01-30',
      sentAt: '2024-01-15T09:15:00',
      paymentLink: 'https://pay.payorchestra.com/inv/INV-002'
    },
    {
      id: '3',
      invoiceNumber: 'INV-003',
      customerName: 'Emma Wilson',
      customerEmail: 'emma@startup.ng',
      items: [
        {
          id: '1',
          description: 'Consulting Services',
          quantity: 10,
          unitPrice: 15000,
          total: 150000
        }
      ],
      subtotal: 150000,
      tax: 11250,
      total: 161250,
      status: 'overdue',
      createdAt: '2024-01-05',
      dueDate: '2024-01-20',
      sentAt: '2024-01-05T16:45:00',
      paymentLink: 'https://pay.payorchestra.com/inv/INV-003'
    }
  ]);

  const [newInvoice, setNewInvoice] = useState<Partial<Invoice>>({
    customerName: '',
    customerEmail: '',
    customerAddress: '',
    items: [
      {
        id: '1',
        description: '',
        quantity: 1,
        unitPrice: 0,
        total: 0
      }
    ],
    dueDate: '',
    notes: ''
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-500/20 text-green-400';
      case 'sent':
        return 'bg-blue-500/20 text-blue-400';
      case 'overdue':
        return 'bg-red-500/20 text-red-400';
      case 'draft':
        return 'bg-gray-500/20 text-gray-400';
      case 'cancelled':
        return 'bg-yellow-500/20 text-yellow-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'sent':
        return <Mail className="w-4 h-4 text-blue-500" />;
      case 'overdue':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'draft':
        return <FileText className="w-4 h-4 text-gray-500" />;
      case 'cancelled':
        return <Trash2 className="w-4 h-4 text-yellow-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const addInvoiceItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      unitPrice: 0,
      total: 0
    };
    setNewInvoice(prev => ({
      ...prev,
      items: [...(prev.items || []), newItem]
    }));
  };

  const updateInvoiceItem = (itemId: string, field: keyof InvoiceItem, value: string | number) => {
    setNewInvoice(prev => ({
      ...prev,
      items: prev.items?.map(item => {
        if (item.id === itemId) {
          const updatedItem = { ...item, [field]: value };
          if (field === 'quantity' || field === 'unitPrice') {
            updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
          }
          return updatedItem;
        }
        return item;
      })
    }));
  };

  const removeInvoiceItem = (itemId: string) => {
    setNewInvoice(prev => ({
      ...prev,
      items: prev.items?.filter(item => item.id !== itemId)
    }));
  };

  const calculateInvoiceTotals = () => {
    const subtotal = newInvoice.items?.reduce((sum, item) => sum + item.total, 0) || 0;
    const tax = subtotal * 0.075; // 7.5% VAT
    const total = subtotal + tax;
    return { subtotal, tax, total };
  };

  const createInvoice = () => {
    const { subtotal, tax, total } = calculateInvoiceTotals();
    const invoiceNumber = `INV-${String(invoices.length + 1).padStart(3, '0')}`;
    
    const invoice: Invoice = {
      id: Date.now().toString(),
      invoiceNumber,
      customerName: newInvoice.customerName || '',
      customerEmail: newInvoice.customerEmail || '',
      customerAddress: newInvoice.customerAddress,
      items: newInvoice.items || [],
      subtotal,
      tax,
      total,
      status: 'draft',
      createdAt: new Date().toISOString().split('T')[0],
      dueDate: newInvoice.dueDate || '',
      paymentLink: `https://pay.payorchestra.com/inv/${invoiceNumber}`,
      notes: newInvoice.notes
    };

    setInvoices(prev => [invoice, ...prev]);
    setNewInvoice({
      customerName: '',
      customerEmail: '',
      customerAddress: '',
      items: [{ id: '1', description: '', quantity: 1, unitPrice: 0, total: 0 }],
      dueDate: '',
      notes: ''
    });
    setShowCreateInvoice(false);
  };

  const sendInvoice = (invoiceId: string) => {
    setInvoices(prev => prev.map(invoice => {
      if (invoice.id === invoiceId) {
        return {
          ...invoice,
          status: 'sent' as const,
          sentAt: new Date().toISOString()
        };
      }
      return invoice;
    }));
    
    // Simulate email sending
    alert('Invoice sent successfully! The customer will receive an email with the payment link.');
  };

  const copyPaymentLink = (link: string) => {
    navigator.clipboard.writeText(link);
    alert('Payment link copied to clipboard!');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Invoices</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{invoices.length}</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <FileText className="w-6 h-6 text-blue-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Paid Invoices</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {invoices.filter(inv => inv.status === 'paid').length}
              </p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Outstanding</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {formatCurrency(invoices.filter(inv => inv.status === 'sent' || inv.status === 'overdue').reduce((sum, inv) => sum + inv.total, 0))}
              </p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <Clock className="w-6 h-6 text-yellow-500" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">This Month</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {formatCurrency(invoices.reduce((sum, inv) => sum + inv.total, 0))}
              </p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-purple-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Invoices */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Invoices</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Latest invoice activity</p>
            </div>
            <button
              onClick={() => setActiveTab('all')}
              className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm font-medium"
            >
              View all
            </button>
          </div>
        </div>
        
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {invoices.slice(0, 5).map((invoice) => (
            <div key={invoice.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-full">
                    <FileText className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{invoice.invoiceNumber}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{invoice.customerName}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-500">Due: {formatDate(invoice.dueDate)}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{formatCurrency(invoice.total)}</p>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(invoice.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(invoice.status)}`}>
                        {invoice.status}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedInvoice(invoice);
                        setShowInvoicePreview(true);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {invoice.status === 'draft' && (
                      <button
                        onClick={() => sendInvoice(invoice.id)}
                        className="p-1 text-gray-400 hover:text-green-500 transition-colors"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderAllInvoices = () => (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">All Invoices</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">Manage all your invoices</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Invoice</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Customer</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Due Date</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-600 dark:text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((invoice) => (
                <tr key={invoice.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{invoice.invoiceNumber}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">Created: {formatDate(invoice.createdAt)}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm text-gray-900 dark:text-white">{invoice.customerName}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">{invoice.customerEmail}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm font-medium text-gray-900 dark:text-white">
                    {formatCurrency(invoice.total)}
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-1">
                      {getStatusIcon(invoice.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(invoice.status)}`}>
                        {invoice.status}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-600 dark:text-gray-400">
                    {formatDate(invoice.dueDate)}
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setSelectedInvoice(invoice);
                          setShowInvoicePreview(true);
                        }}
                        className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {invoice.status === 'draft' && (
                        <button
                          onClick={() => sendInvoice(invoice.id)}
                          className="p-1 text-gray-400 hover:text-green-500 transition-colors"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => copyPaymentLink(invoice.paymentLink)}
                        className="p-1 text-gray-400 hover:text-purple-500 transition-colors"
                      >
                        <Link className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Invoices</h2>
          <p className="text-gray-600 dark:text-gray-400">Create and manage digital invoices</p>
        </div>
        <button
          onClick={() => setShowCreateInvoice(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
        >
          <Plus className="w-4 h-4" />
          Create Invoice
        </button>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
        {[
          { id: 'overview', name: 'Overview' },
          { id: 'all', name: 'All Invoices' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
            }`}
          >
            {tab.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'all' && renderAllInvoices()}

      {/* Create Invoice Modal */}
      {showCreateInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Create New Invoice</h3>
                <button
                  onClick={() => setShowCreateInvoice(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Customer Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    value={newInvoice.customerName}
                    onChange={(e) => setNewInvoice(prev => ({ ...prev, customerName: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Enter customer name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Customer Email *
                  </label>
                  <input
                    type="email"
                    value={newInvoice.customerEmail}
                    onChange={(e) => setNewInvoice(prev => ({ ...prev, customerEmail: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="customer@example.com"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Customer Address
                  </label>
                  <textarea
                    value={newInvoice.customerAddress}
                    onChange={(e) => setNewInvoice(prev => ({ ...prev, customerAddress: e.target.value }))}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Enter customer address"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Due Date *
                  </label>
                  <input
                    type="date"
                    value={newInvoice.dueDate}
                    onChange={(e) => setNewInvoice(prev => ({ ...prev, dueDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>

              {/* Invoice Items */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-medium text-gray-900 dark:text-white">Invoice Items</h4>
                  <button
                    onClick={addInvoiceItem}
                    className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white text-sm transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Add Item
                  </button>
                </div>
                
                <div className="space-y-4">
                  {newInvoice.items?.map((item, index) => (
                    <div key={item.id} className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Description
                        </label>
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => updateInvoiceItem(item.id, 'description', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Item description"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Quantity
                        </label>
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateInvoiceItem(item.id, 'quantity', Number(e.target.value))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                          min="1"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Unit Price (₦)
                        </label>
                        <input
                          type="number"
                          value={item.unitPrice}
                          onChange={(e) => updateInvoiceItem(item.id, 'unitPrice', Number(e.target.value))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                          min="0"
                        />
                      </div>
                      
                      <div className="flex items-end gap-2">
                        <div className="flex-1">
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Total
                          </label>
                          <div className="px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white">
                            {formatCurrency(item.total)}
                          </div>
                        </div>
                        {newInvoice.items && newInvoice.items.length > 1 && (
                          <button
                            onClick={() => removeInvoiceItem(item.id)}
                            className="p-2 text-red-500 hover:text-red-700 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Invoice Totals */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                <div className="max-w-md ml-auto space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Subtotal:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {formatCurrency(calculateInvoiceTotals().subtotal)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">VAT (7.5%):</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {formatCurrency(calculateInvoiceTotals().tax)}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg font-bold border-t border-gray-200 dark:border-gray-700 pt-2">
                    <span className="text-gray-900 dark:text-white">Total:</span>
                    <span className="text-gray-900 dark:text-white">
                      {formatCurrency(calculateInvoiceTotals().total)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Notes
                </label>
                <textarea
                  value={newInvoice.notes}
                  onChange={(e) => setNewInvoice(prev => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  placeholder="Additional notes or terms..."
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex gap-3">
              <button
                onClick={() => setShowCreateInvoice(false)}
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={createInvoice}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                Create Invoice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Preview Modal */}
      {showInvoicePreview && selectedInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Invoice Preview</h3>
                <div className="flex gap-2">
                  {selectedInvoice.status === 'draft' && (
                    <button
                      onClick={() => {
                        sendInvoice(selectedInvoice.id);
                        setShowInvoicePreview(false);
                      }}
                      className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                    >
                      <Send className="w-4 h-4" />
                      Send Invoice
                    </button>
                  )}
                  <button
                    onClick={() => copyPaymentLink(selectedInvoice.paymentLink)}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                    Copy Link
                  </button>
                  <button
                    onClick={() => setShowInvoicePreview(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Invoice Content */}
            <div className="p-8 bg-white dark:bg-gray-900">
              <div className="max-w-3xl mx-auto">
                {/* Header */}
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">INVOICE</h1>
                    <p className="text-gray-600 dark:text-gray-400">#{selectedInvoice.invoiceNumber}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400 mb-2">PayOrchestra</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Digital Payment Solutions</p>
                  </div>
                </div>

                {/* Invoice Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Bill To:</h3>
                    <p className="text-gray-900 dark:text-white font-medium">{selectedInvoice.customerName}</p>
                    <p className="text-gray-600 dark:text-gray-400">{selectedInvoice.customerEmail}</p>
                    {selectedInvoice.customerAddress && (
                      <p className="text-gray-600 dark:text-gray-400 mt-1">{selectedInvoice.customerAddress}</p>
                    )}
                  </div>
                  
                  <div className="text-right">
                    <div className="mb-4">
                      <p className="text-gray-600 dark:text-gray-400">Invoice Date:</p>
                      <p className="font-medium text-gray-900 dark:text-white">{formatDate(selectedInvoice.createdAt)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 dark:text-gray-400">Due Date:</p>
                      <p className="font-medium text-gray-900 dark:text-white">{formatDate(selectedInvoice.dueDate)}</p>
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <div className="mb-8">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b-2 border-gray-200 dark:border-gray-700">
                        <th className="text-left py-3 text-gray-900 dark:text-white">Description</th>
                        <th className="text-center py-3 text-gray-900 dark:text-white">Qty</th>
                        <th className="text-right py-3 text-gray-900 dark:text-white">Unit Price</th>
                        <th className="text-right py-3 text-gray-900 dark:text-white">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedInvoice.items.map((item) => (
                        <tr key={item.id} className="border-b border-gray-100 dark:border-gray-700">
                          <td className="py-3 text-gray-900 dark:text-white">{item.description}</td>
                          <td className="py-3 text-center text-gray-600 dark:text-gray-400">{item.quantity}</td>
                          <td className="py-3 text-right text-gray-600 dark:text-gray-400">{formatCurrency(item.unitPrice)}</td>
                          <td className="py-3 text-right text-gray-900 dark:text-white font-medium">{formatCurrency(item.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Totals */}
                <div className="flex justify-end mb-8">
                  <div className="w-64">
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600 dark:text-gray-400">Subtotal:</span>
                      <span className="text-gray-900 dark:text-white">{formatCurrency(selectedInvoice.subtotal)}</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600 dark:text-gray-400">VAT (7.5%):</span>
                      <span className="text-gray-900 dark:text-white">{formatCurrency(selectedInvoice.tax)}</span>
                    </div>
                    <div className="flex justify-between py-3 border-t-2 border-gray-200 dark:border-gray-700 font-bold text-lg">
                      <span className="text-gray-900 dark:text-white">Total:</span>
                      <span className="text-gray-900 dark:text-white">{formatCurrency(selectedInvoice.total)}</span>
                    </div>
                  </div>
                </div>

                {/* Payment Link */}
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
                  <div className="flex items-center gap-3">
                    <Link className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-blue-900 dark:text-blue-100">Payment Link</p>
                      <p className="text-xs text-blue-700 dark:text-blue-300 break-all">{selectedInvoice.paymentLink}</p>
                    </div>
                    <button
                      onClick={() => window.open(selectedInvoice.paymentLink, '_blank')}
                      className="p-2 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Notes */}
                {selectedInvoice.notes && (
                  <div className="mb-6">
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Notes:</h4>
                    <p className="text-gray-600 dark:text-gray-400">{selectedInvoice.notes}</p>
                  </div>
                )}

                {/* Footer */}
                <div className="text-center text-sm text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700 pt-6">
                  <p>Thank you for your business!</p>
                  <p>This invoice was generated by PayOrchestra</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Invoices;