import React, { useState } from 'react';
import { Code, Play, Copy, Book, Key, Zap, ShoppingCart, CheckCircle, Globe, Shield, Webhook, Download } from 'lucide-react';

const API: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState('process-payment');
  const [apiKey, setApiKey] = useState('pk_test_51234567890abcdef');
  const [activeIntegrationTab, setActiveIntegrationTab] = useState('overview');
  const [selectedSDK, setSelectedSDK] = useState('javascript');

  const endpoints = [
    {
      id: 'process-payment',
      name: 'Process Payment',
      method: 'POST',
      path: '/api/v1/payments',
      description: 'Process a payment transaction through the orchestration layer'
    },
    {
      id: 'get-transaction',
      name: 'Get Transaction',
      method: 'GET',
      path: '/api/v1/transactions/:id',
      description: 'Retrieve transaction details by ID'
    },
    {
      id: 'list-providers',
      name: 'List Providers',
      method: 'GET',
      path: '/api/v1/providers',
      description: 'Get list of available payment providers'
    },
    {
      id: 'create-route',
      name: 'Create Route',
      method: 'POST',
      path: '/api/v1/routes',
      description: 'Create a new payment routing rule'
    }
  ];

  const integrationGuides = [
    {
      id: 'ecommerce',
      title: 'E-commerce Integration',
      description: 'Complete guide for integrating payments into your online store',
      icon: ShoppingCart,
      steps: [
        'Generate API keys from Developer Portal',
        'Install PayOrchestra SDK',
        'Initialize payment client',
        'Create checkout form',
        'Handle payment responses',
        'Implement webhooks for order updates'
      ]
    },
    {
      id: 'marketplace',
      title: 'Marketplace Integration',
      description: 'Multi-vendor marketplace payment splitting and management',
      icon: Globe,
      steps: [
        'Set up marketplace account',
        'Configure vendor onboarding',
        'Implement payment splitting',
        'Handle escrow and payouts',
        'Manage dispute resolution'
      ]
    },
    {
      id: 'subscription',
      title: 'Subscription Billing',
      description: 'Recurring payments and subscription management',
      icon: CheckCircle,
      steps: [
        'Create subscription plans',
        'Set up recurring billing',
        'Handle payment failures',
        'Manage plan upgrades/downgrades',
        'Implement dunning management'
      ]
    }
  ];

  const sdkExamples = {
    javascript: {
      installation: `npm install @payorchestra/js-sdk`,
      initialization: `import PayOrchestra from '@payorchestra/js-sdk';

const payorchestra = new PayOrchestra({
  apiKey: '${apiKey}',
  environment: 'sandbox' // or 'production'
});`,
      checkout: `// Create payment intent
const paymentIntent = await payorchestra.createPaymentIntent({
  amount: 1500000, // ₦15,000 in kobo
  currency: 'NGN',
  customer: {
    email: 'customer@example.com',
    name: 'John Doe'
  },
  metadata: {
    orderId: 'ORDER-12345',
    productName: 'Premium Headphones'
  }
});

// Initialize checkout
const checkout = payorchestra.checkout({
  paymentIntentId: paymentIntent.id,
  onSuccess: (payment) => {
    // Payment successful
    console.log('Payment successful:', payment);
    window.location.href = '/order-success';
  },
  onError: (error) => {
    // Payment failed
    console.error('Payment failed:', error);
    alert('Payment failed. Please try again.');
  }
});

// Mount checkout to DOM
checkout.mount('#checkout-container');`,
      webhook: `// Webhook handler (Node.js/Express)
app.post('/webhooks/payorchestra', (req, res) => {
  const signature = req.headers['x-payorchestra-signature'];
  const payload = req.body;
  
  // Verify webhook signature
  const isValid = payorchestra.verifyWebhook(payload, signature);
  
  if (!isValid) {
    return res.status(400).send('Invalid signature');
  }
  
  // Handle payment events
  switch (payload.event) {
    case 'payment.succeeded':
      // Mark order as paid
      await updateOrderStatus(payload.data.metadata.orderId, 'paid');
      break;
    case 'payment.failed':
      // Handle failed payment
      await updateOrderStatus(payload.data.metadata.orderId, 'failed');
      break;
  }
  
  res.status(200).send('OK');
});`
    },
    react: {
      installation: `npm install @payorchestra/react-sdk`,
      initialization: `import { PayOrchestraProvider } from '@payorchestra/react-sdk';

function App() {
  return (
    <PayOrchestraProvider apiKey="${apiKey}" environment="sandbox">
      <YourApp />
    </PayOrchestraProvider>
  );
}`,
      checkout: `import { usePayOrchestra } from '@payorchestra/react-sdk';

function CheckoutPage() {
  const { createPayment, loading } = usePayOrchestra();
  
  const handlePayment = async () => {
    try {
      const result = await createPayment({
        amount: 1500000, // ₦15,000 in kobo
        currency: 'NGN',
        customer: {
          email: 'customer@example.com',
          name: 'John Doe'
        },
        metadata: {
          orderId: 'ORDER-12345'
        }
      });
      
      if (result.status === 'succeeded') {
        // Payment successful
        router.push('/order-success');
      }
    } catch (error) {
      console.error('Payment failed:', error);
    }
  };
  
  return (
    <button 
      onClick={handlePayment} 
      disabled={loading}
      className="bg-blue-600 text-white px-6 py-3 rounded-lg"
    >
      {loading ? 'Processing...' : 'Pay ₦15,000'}
    </button>
  );
}`,
      webhook: `// Next.js API route: /api/webhooks/payorchestra
import { NextApiRequest, NextApiResponse } from 'next';
import { PayOrchestra } from '@payorchestra/react-sdk';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).end();
  }
  
  const signature = req.headers['x-payorchestra-signature'] as string;
  const isValid = PayOrchestra.verifyWebhook(req.body, signature);
  
  if (!isValid) {
    return res.status(400).json({ error: 'Invalid signature' });
  }
  
  const { event, data } = req.body;
  
  switch (event) {
    case 'payment.succeeded':
      // Update order status in database
      await updateOrder(data.metadata.orderId, { status: 'paid' });
      break;
  }
  
  res.status(200).json({ received: true });
}`
    },
    php: {
      installation: `composer require payorchestra/php-sdk`,
      initialization: `<?php
require_once 'vendor/autoload.php';

use PayOrchestra\\PayOrchestra;

$payorchestra = new PayOrchestra([
    'api_key' => '${apiKey}',
    'environment' => 'sandbox'
]);`,
      checkout: `<?php
// Create payment intent
$paymentIntent = $payorchestra->createPaymentIntent([
    'amount' => 1500000, // ₦15,000 in kobo
    'currency' => 'NGN',
    'customer' => [
        'email' => 'customer@example.com',
        'name' => 'John Doe'
    ],
    'metadata' => [
        'order_id' => 'ORDER-12345',
        'product_name' => 'Premium Headphones'
    ]
]);

// Redirect to checkout
header('Location: ' . $paymentIntent['checkout_url']);
exit;`,
      webhook: `<?php
// Webhook handler
$signature = $_SERVER['HTTP_X_PAYORCHESTRA_SIGNATURE'];
$payload = file_get_contents('php://input');

// Verify webhook signature
if (!$payorchestra->verifyWebhook($payload, $signature)) {
    http_response_code(400);
    exit('Invalid signature');
}

$event = json_decode($payload, true);

switch ($event['event']) {
    case 'payment.succeeded':
        // Update order status
        updateOrderStatus($event['data']['metadata']['order_id'], 'paid');
        break;
    case 'payment.failed':
        updateOrderStatus($event['data']['metadata']['order_id'], 'failed');
        break;
}

http_response_code(200);
echo 'OK';`
    }
  };

  const codeExamples = {
    'process-payment': {
      curl: `curl -X POST https://api.payorchestra.com/v1/payments \\
  -H "Authorization: Bearer ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "amount": 1000,
    "currency": "USD",
    "customer": {
      "email": "customer@example.com"
    },
    "payment_method": {
      "type": "card",
      "card": {
        "number": "4242424242424242",
        "exp_month": 12,
        "exp_year": 2025,
        "cvc": "123"
      }
    }
  }'`,
      javascript: `const payment = await fetch('https://api.payorchestra.com/v1/payments', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ${apiKey}',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: 1000,
    currency: 'USD',
    customer: {
      email: 'customer@example.com'
    },
    payment_method: {
      type: 'card',
      card: {
        number: '4242424242424242',
        exp_month: 12,
        exp_year: 2025,
        cvc: '123'
      }
    }
  })
});

const result = await payment.json();`,
      python: `import requests

response = requests.post(
    'https://api.payorchestra.com/v1/payments',
    headers={
        'Authorization': f'Bearer ${apiKey}',
        'Content-Type': 'application/json'
    },
    json={
        'amount': 1000,
        'currency': 'USD',
        'customer': {
            'email': 'customer@example.com'
        },
        'payment_method': {
            'type': 'card',
            'card': {
                'number': '4242424242424242',
                'exp_month': 12,
                'exp_year': 2025,
                'cvc': '123'
            }
        }
    }
)

result = response.json()`
    },
    'get-transaction': {
      curl: `curl -X GET https://api.payorchestra.com/v1/transactions/tx_12345 \\
  -H "Authorization: Bearer ${apiKey}"`,
      javascript: `const transaction = await fetch('https://api.payorchestra.com/v1/transactions/tx_12345', {
  headers: {
    'Authorization': 'Bearer ${apiKey}'
  }
});

const result = await transaction.json();`,
      python: `import requests

response = requests.get(
    'https://api.payorchestra.com/v1/transactions/tx_12345',
    headers={
        'Authorization': f'Bearer ${apiKey}'
    }
)

result = response.json()`
    }
  };

  const [selectedLanguage, setSelectedLanguage] = useState('curl');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const renderIntegrationGuides = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {integrationGuides.map((guide) => {
          const Icon = guide.icon;
          return (
            <div key={guide.id} className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-gray-600 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <Icon className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-white">{guide.title}</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4">{guide.description}</p>
              <div className="space-y-2">
                {guide.steps.slice(0, 3).map((step, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm text-gray-300">
                    <div className="w-5 h-5 bg-blue-500/20 rounded-full flex items-center justify-center">
                      <span className="text-xs text-blue-400">{index + 1}</span>
                    </div>
                    <span>{step}</span>
                  </div>
                ))}
                <div className="text-xs text-gray-500">+{guide.steps.length - 3} more steps</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderSDKExamples = () => (
    <div className="space-y-6">
      {/* SDK Selection */}
      <div className="flex gap-2 bg-gray-800 rounded-lg p-1">
        {Object.keys(sdkExamples).map((sdk) => (
          <button
            key={sdk}
            onClick={() => setSelectedSDK(sdk)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              selectedSDK === sdk
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {sdk.charAt(0).toUpperCase() + sdk.slice(1)}
          </button>
        ))}
      </div>

      {/* SDK Documentation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          {/* Installation */}
          <div className="bg-gray-800 rounded-lg border border-gray-700">
            <div className="p-4 border-b border-gray-700">
              <h4 className="text-lg font-semibold text-white">1. Installation</h4>
            </div>
            <div className="p-4">
              <pre className="bg-gray-900 rounded-lg p-4 text-sm text-gray-300 overflow-x-auto">
                <code>{sdkExamples[selectedSDK as keyof typeof sdkExamples].installation}</code>
              </pre>
            </div>
          </div>

          {/* Initialization */}
          <div className="bg-gray-800 rounded-lg border border-gray-700">
            <div className="p-4 border-b border-gray-700">
              <h4 className="text-lg font-semibold text-white">2. Initialization</h4>
            </div>
            <div className="p-4">
              <pre className="bg-gray-900 rounded-lg p-4 text-sm text-gray-300 overflow-x-auto">
                <code>{sdkExamples[selectedSDK as keyof typeof sdkExamples].initialization}</code>
              </pre>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Checkout Implementation */}
          <div className="bg-gray-800 rounded-lg border border-gray-700">
            <div className="p-4 border-b border-gray-700">
              <h4 className="text-lg font-semibold text-white">3. Checkout Implementation</h4>
            </div>
            <div className="p-4">
              <pre className="bg-gray-900 rounded-lg p-4 text-sm text-gray-300 overflow-x-auto">
                <code>{sdkExamples[selectedSDK as keyof typeof sdkExamples].checkout}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>

      {/* Webhook Implementation */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-4 border-b border-gray-700">
          <h4 className="text-lg font-semibold text-white">4. Webhook Implementation</h4>
          <p className="text-sm text-gray-400 mt-1">Handle payment status updates and mark orders as paid</p>
        </div>
        <div className="p-4">
          <pre className="bg-gray-900 rounded-lg p-4 text-sm text-gray-300 overflow-x-auto">
            <code>{sdkExamples[selectedSDK as keyof typeof sdkExamples].webhook}</code>
          </pre>
        </div>
      </div>
    </div>
  );

  const renderTestingTools = () => (
    <div className="space-y-6">
      {/* Test Cards */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Test Payment Methods</h3>
          <p className="text-sm text-gray-400 mt-1">Use these test cards to simulate different payment scenarios</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Card Number</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Brand</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Scenario</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Expected Result</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-700/50">
                <td className="py-4 px-6 text-sm font-mono text-white">4242 4242 4242 4242</td>
                <td className="py-4 px-6 text-sm text-gray-300">Visa</td>
                <td className="py-4 px-6 text-sm text-gray-300">Successful Payment</td>
                <td className="py-4 px-6">
                  <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs">Success</span>
                </td>
              </tr>
              <tr className="border-b border-gray-700/50">
                <td className="py-4 px-6 text-sm font-mono text-white">4000 0000 0000 0002</td>
                <td className="py-4 px-6 text-sm text-gray-300">Visa</td>
                <td className="py-4 px-6 text-sm text-gray-300">Declined Payment</td>
                <td className="py-4 px-6">
                  <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs">Declined</span>
                </td>
              </tr>
              <tr className="border-b border-gray-700/50">
                <td className="py-4 px-6 text-sm font-mono text-white">4000 0000 0000 9995</td>
                <td className="py-4 px-6 text-sm text-gray-300">Visa</td>
                <td className="py-4 px-6 text-sm text-gray-300">Insufficient Funds</td>
                <td className="py-4 px-6">
                  <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded text-xs">Failed</span>
                </td>
              </tr>
              <tr className="border-b border-gray-700/50">
                <td className="py-4 px-6 text-sm font-mono text-white">5555 5555 5555 4444</td>
                <td className="py-4 px-6 text-sm text-gray-300">Mastercard</td>
                <td className="py-4 px-6 text-sm text-gray-300">Successful Payment</td>
                <td className="py-4 px-6">
                  <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs">Success</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Webhook Testing */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Webhook Testing</h3>
          <p className="text-sm text-gray-400 mt-1">Test your webhook endpoints with simulated events</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Webhook URL</label>
              <input
                type="url"
                placeholder="https://yoursite.com/webhooks/payorchestra"
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Event Type</label>
              <select className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500">
                <option value="payment.succeeded">payment.succeeded</option>
                <option value="payment.failed">payment.failed</option>
                <option value="payment.pending">payment.pending</option>
                <option value="refund.created">refund.created</option>
              </select>
            </div>
          </div>
          <button className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            Send Test Event
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">API Documentation</h2>
          <p className="text-gray-400">Integrate with our payment orchestration platform</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
            <Download className="w-4 h-4" />
            Download SDK
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
            <Book className="w-4 h-4" />
            Full Docs
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Key className="w-4 h-4" />
            Get API Key
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">API Endpoints</p>
              <p className="text-2xl font-bold text-white">25</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Code className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Avg Response Time</p>
              <p className="text-2xl font-bold text-white">120ms</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <Zap className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">API Uptime</p>
              <p className="text-2xl font-bold text-white">99.9%</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <Play className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
        {[
          { id: 'overview', name: 'API Reference' },
          { id: 'integration', name: 'Integration Guides' },
          { id: 'sdks', name: 'SDKs & Examples' },
          { id: 'testing', name: 'Testing Tools' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveIntegrationTab(tab.id)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeIntegrationTab === tab.id
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeIntegrationTab === 'overview' && (
        <>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Endpoints List */}
          <div className="bg-gray-800 rounded-lg border border-gray-700">
            <div className="p-6 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-white">API Endpoints</h3>
              <p className="text-sm text-gray-400 mt-1">Select an endpoint to view details</p>
            </div>
            
            <div className="divide-y divide-gray-700">
              {endpoints.map((endpoint) => (
                <button
                  key={endpoint.id}
                  onClick={() => setSelectedEndpoint(endpoint.id)}
                  className={`w-full text-left p-4 hover:bg-gray-700/30 transition-colors ${
                    selectedEndpoint === endpoint.id ? 'bg-gray-700/50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          endpoint.method === 'POST' ? 'bg-green-500/20 text-green-400' :
                          endpoint.method === 'GET' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {endpoint.method}
                        </span>
                        <span className="text-sm font-medium text-white">{endpoint.name}</span>
                      </div>
                      <p className="text-sm text-gray-400 font-mono">{endpoint.path}</p>
                      <p className="text-xs text-gray-500 mt-1">{endpoint.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Code Examples */}
          <div className="bg-gray-800 rounded-lg border border-gray-700">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">Code Examples</h3>
                <div className="flex gap-2">
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    className="px-3 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
                  >
                    <option value="curl">cURL</option>
                    <option value="javascript">JavaScript</option>
                    <option value="python">Python</option>
                  </select>
                  <button
                    onClick={() => copyToClipboard(codeExamples[selectedEndpoint as keyof typeof codeExamples]?.[selectedLanguage as keyof typeof codeExamples['process-payment']] || '')}
                    className="p-2 text-gray-400 hover:text-white transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="p-6">
              <pre className="bg-gray-900 rounded-lg p-4 text-sm text-gray-300 overflow-x-auto">
                <code>
                  {codeExamples[selectedEndpoint as keyof typeof codeExamples]?.[selectedLanguage as keyof typeof codeExamples['process-payment']] || 'Example not available'}
                </code>
              </pre>
            </div>
          </div>
        </div>

        {/* E-commerce Integration Scenario */}
        <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-green-400" />
            </div>
            <div className="flex-1">
              <h4 className="font-medium text-green-400 mb-2">E-commerce Integration Success</h4>
              <p className="text-sm text-gray-300 mb-3">
                Complete implementation example: Customer places order for ₦15,000, payment is authorized and captured, 
                order status updated to "Paid" via webhook.
              </p>
              <div className="flex items-center gap-4 text-sm text-gray-400">
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>API Keys Generated</span>
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>SDK Integrated</span>
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>Payment Captured</span>
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>Order Updated</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        </>
      )}
      
      {activeIntegrationTab === 'integration' && renderIntegrationGuides()}
      {activeIntegrationTab === 'sdks' && renderSDKExamples()}
      {activeIntegrationTab === 'testing' && renderTestingTools()}

      {/* API Key Management */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">API Key Management</h3>
          <p className="text-sm text-gray-400 mt-1">Manage your API keys and authentication</p>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Test API Key</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  placeholder="Enter your API key"
                />
                <button
                  onClick={() => copyToClipboard(apiKey)}
                  className="p-2 text-gray-400 hover:text-white transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
                Generate New Key
              </button>
              <button className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
                Revoke Key
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default API;