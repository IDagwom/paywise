import React from 'react';

interface ChartProps {
  title: string;
  subtitle: string;
  data: Array<{ name: string; value: number }>;
  type: 'area' | 'bar';
  color: string;
}

const Chart: React.FC<ChartProps> = ({ title, subtitle, data, type, color }) => {
  const maxValue = Math.max(...data.map(d => d.value));
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400">{subtitle}</p>
      </div>
      
      <div className="h-64">
        {type === 'area' ? (
          <div className="flex items-end justify-between h-full space-x-2">
            {data.map((point, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-t-sm relative overflow-hidden" style={{ height: '200px' }}>
                  <div
                    className="absolute bottom-0 w-full rounded-t-sm transition-all duration-1000 ease-out"
                    style={{
                      height: `${(point.value / maxValue) * 100}%`,
                      backgroundColor: color,
                      opacity: 0.7,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400 mt-2">{point.name}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-end justify-between h-full space-x-2">
            {data.map((point, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div
                  className="w-full rounded-t-sm transition-all duration-1000 ease-out"
                  style={{
                    height: `${(point.value / maxValue) * 200}px`,
                    backgroundColor: color,
                    opacity: 0.8,
                  }}
                />
                <span className="text-xs text-gray-500 dark:text-gray-400 mt-2">{point.name}</span>
                <span className="text-xs text-gray-600 dark:text-gray-500">{point.value}%</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Chart;