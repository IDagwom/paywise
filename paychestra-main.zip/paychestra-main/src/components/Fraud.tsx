import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, XCircle, Plus, Settings } from 'lucide-react';

const Fraud: React.FC = () => {
  const [rules, setRules] = useState([
    {
      id: 1,
      name: 'High Value Transactions',
      type: 'amount',
      condition: 'greater_than',
      value: '5000',
      action: 'review',
      status: 'active',
      triggered: 23,
      description: 'Flag transactions over $5,000 for manual review'
    },
    {
      id: 2,
      name: 'Velocity Check',
      type: 'velocity',
      condition: 'count_per_hour',
      value: '10',
      action: 'block',
      status: 'active',
      triggered: 7,
      description: 'Block if more than 10 transactions per hour from same IP'
    },
    {
      id: 3,
      name: 'Suspicious Countries',
      type: 'location',
      condition: 'in_list',
      value: 'high_risk_countries',
      action: 'additional_verification',
      status: 'active',
      triggered: 15,
      description: 'Require additional verification for high-risk countries'
    },
    {
      id: 4,
      name: 'Card Testing Pattern',
      type: 'pattern',
      condition: 'multiple_failures',
      value: '5',
      action: 'block',
      status: 'active',
      triggered: 12,
      description: 'Block after 5 consecutive failed attempts'
    }
  ]);

  const recentAlerts = [
    {
      id: 1,
      timestamp: '2024-01-15 14:30:22',
      type: 'high_value',
      description: 'Transaction TX-12345 flagged for high amount: $7,500',
      status: 'pending',
      risk: 'medium'
    },
    {
      id: 2,
      timestamp: '2024-01-15 14:25:11',
      description: 'Multiple failed attempts detected from IP 192.168.1.100',
      type: 'velocity',
      status: 'blocked',
      risk: 'high'
    },
    {
      id: 3,
      timestamp: '2024-01-15 14:20:05',
      type: 'location',
      description: 'Transaction from restricted country detected',
      status: 'reviewed',
      risk: 'low'
    },
    {
      id: 4,
      timestamp: '2024-01-15 14:15:33',
      type: 'pattern',
      description: 'Suspicious card testing pattern identified',
      status: 'blocked',
      risk: 'high'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-400';
      case 'inactive':
        return 'bg-gray-500/20 text-gray-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getAlertStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'blocked':
        return 'bg-red-500/20 text-red-400';
      case 'reviewed':
        return 'bg-green-500/20 text-green-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'block':
        return 'bg-red-500/20 text-red-400';
      case 'review':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'additional_verification':
        return 'bg-blue-500/20 text-blue-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Fraud Detection</h2>
          <p className="text-gray-400">Monitor and prevent fraudulent transactions</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <Plus className="w-4 h-4" />
          Add Rule
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Rules</p>
              <p className="text-2xl font-bold text-white">4</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Shield className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Blocked Today</p>
              <p className="text-2xl font-bold text-white">57</p>
            </div>
            <div className="p-3 bg-red-500/20 rounded-lg">
              <XCircle className="w-6 h-6 text-red-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Under Review</p>
              <p className="text-2xl font-bold text-white">12</p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">False Positive Rate</p>
              <p className="text-2xl font-bold text-white">2.3%</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Fraud Rules */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Fraud Detection Rules</h3>
          <p className="text-sm text-gray-400 mt-1">Configure rules to automatically detect and handle suspicious activity</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700/50">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Rule Name</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Type</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Condition</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Action</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Triggered</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((rule) => (
                <tr key={rule.id} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-white">{rule.name}</p>
                      <p className="text-xs text-gray-400">{rule.description}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="px-2 py-1 bg-gray-700 rounded text-xs text-gray-300 capitalize">
                      {rule.type}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-300">
                    {rule.condition.replace('_', ' ')} {rule.value}
                  </td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getActionColor(rule.action)}`}>
                      {rule.action.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(rule.status)}`}>
                      {rule.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-sm text-white">{rule.triggered}</td>
                  <td className="py-4 px-6">
                    <div className="flex gap-2">
                      <button className="p-1 text-gray-400 hover:text-blue-400 transition-colors">
                        <Settings className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Alerts */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">Recent Alerts</h3>
          <p className="text-sm text-gray-400 mt-1">Latest fraud detection alerts and actions taken</p>
        </div>
        
        <div className="divide-y divide-gray-700">
          {recentAlerts.map((alert) => (
            <div key={alert.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-sm text-gray-400">{alert.timestamp}</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getAlertStatusColor(alert.status)}`}>
                      {alert.status}
                    </span>
                    <span className={`text-xs font-medium ${getRiskColor(alert.risk)}`}>
                      {alert.risk} risk
                    </span>
                  </div>
                  <p className="text-sm text-gray-300">{alert.description}</p>
                </div>
                <div className="flex gap-2 ml-4">
                  <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs text-white transition-colors">
                    Review
                  </button>
                  <button className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white transition-colors">
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Fraud;