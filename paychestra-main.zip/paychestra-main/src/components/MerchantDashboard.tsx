import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  CreditCard, 
  Users, 
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Eye,
  Download,
  Plus,
  Settings,
  Bell,
  HelpCircle,
  Search,
  Filter,
  Link,
  UserPlus,
  QrCode
} from 'lucide-react';

interface MerchantDashboardProps {
  activeSection?: string;
}

const MerchantDashboard: React.FC<MerchantDashboardProps> = ({ activeSection = 'dashboard' }) => {
  const [timeRange, setTimeRange] = useState('7d');
  const [searchTerm, setSearchTerm] = useState('');

  // Sample data for small business
  const todayStats = {
    revenue: 1247.50,
    transactions: 23,
    customers: 18,
    avgOrder: 54.24
  };

  const weeklyStats = {
    revenue: 8932.75,
    transactions: 156,
    customers: 89,
    avgOrder: 57.26
  };

  const recentTransactions = [
    {
      id: 'TXN-001',
      customer: 'Sarah Johnson',
      amount: 89.99,
      status: 'completed',
      time: '2 minutes ago',
      method: 'Visa ****4242'
    },
    {
      id: 'TXN-002',
      customer: 'Mike Chen',
      amount: 156.50,
      status: 'completed',
      time: '15 minutes ago',
      method: 'Mastercard ****8888'
    },
    {
      id: 'TXN-003',
      customer: 'Emma Wilson',
      amount: 45.00,
      status: 'pending',
      time: '32 minutes ago',
      method: 'PayPal'
    },
    {
      id: 'TXN-004',
      customer: 'David Brown',
      amount: 234.75,
      status: 'failed',
      time: '1 hour ago',
      method: 'Visa ****1234'
    },
    {
      id: 'TXN-005',
      customer: 'Lisa Garcia',
      amount: 67.25,
      status: 'completed',
      time: '2 hours ago',
      method: 'Apple Pay'
    }
  ];

  const weeklyData = [
    { day: 'Mon', amount: 1250 },
    { day: 'Tue', amount: 1890 },
    { day: 'Wed', amount: 1456 },
    { day: 'Thu', amount: 2100 },
    { day: 'Fri', amount: 1876 },
    { day: 'Sat', amount: 890 },
    { day: 'Sun', amount: 470 }
  ];

  const maxAmount = Math.max(...weeklyData.map(d => d.amount));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-400';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const customers = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      totalSpent: 1245.50,
      orders: 12,
      lastOrder: '2024-01-15',
      status: 'active'
    },
    {
      id: 2,
      name: 'Mike Chen',
      email: 'mike@example.com',
      totalSpent: 890.25,
      orders: 8,
      lastOrder: '2024-01-14',
      status: 'active'
    },
    {
      id: 3,
      name: 'Emma Wilson',
      email: 'emma@example.com',
      totalSpent: 567.75,
      orders: 5,
      lastOrder: '2024-01-12',
      status: 'inactive'
    }
  ];

  const paymentLinks = [
    {
      id: 1,
      title: 'Product Consultation',
      amount: 150.00,
      clicks: 23,
      conversions: 5,
      created: '2024-01-10',
      status: 'active'
    },
    {
      id: 2,
      title: 'Monthly Subscription',
      amount: 29.99,
      clicks: 156,
      conversions: 45,
      created: '2024-01-05',
      status: 'active'
    }
  ];

  const renderDashboardContent = () => (
    <>
      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-400" />
            </div>
            <div className="flex items-center text-green-400 text-sm">
              <ArrowUpRight className="w-4 h-4" />
              <span>+12.5%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">${todayStats.revenue.toLocaleString()}</p>
            <p className="text-sm text-gray-400">Today's Revenue</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <CreditCard className="w-6 h-6 text-blue-400" />
            </div>
            <div className="flex items-center text-green-400 text-sm">
              <ArrowUpRight className="w-4 h-4" />
              <span>+8.3%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{todayStats.transactions}</p>
            <p className="text-sm text-gray-400">Transactions</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Users className="w-6 h-6 text-purple-400" />
            </div>
            <div className="flex items-center text-green-400 text-sm">
              <ArrowUpRight className="w-4 h-4" />
              <span>+15.2%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{todayStats.customers}</p>
            <p className="text-sm text-gray-400">Customers</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-yellow-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-400" />
            </div>
            <div className="flex items-center text-red-400 text-sm">
              <ArrowDownRight className="w-4 h-4" />
              <span>-2.1%</span>
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">${todayStats.avgOrder.toFixed(2)}</p>
            <p className="text-sm text-gray-400">Avg Order Value</p>
          </div>
        </div>
      </div>

      {/* Revenue Chart and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Weekly Revenue</h3>
              <p className="text-sm text-gray-400">Last 7 days performance</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white">${weeklyStats.revenue.toLocaleString()}</p>
              <p className="text-sm text-green-400">+18.5% vs last week</p>
            </div>
          </div>
          
          <div className="h-48 flex items-end justify-between space-x-2">
            {weeklyData.map((day, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full bg-gray-700 rounded-t-sm relative overflow-hidden" style={{ height: '160px' }}>
                  <div
                    className="absolute bottom-0 w-full bg-blue-500 rounded-t-sm transition-all duration-1000 ease-out"
                    style={{
                      height: `${(day.amount / maxAmount) * 100}%`,
                      opacity: 0.8,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-400 mt-2">{day.day}</span>
                <span className="text-xs text-gray-500">${day.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full flex items-center gap-3 p-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
              <Plus className="w-5 h-5" />
              <span>Create Payment Link</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Download className="w-5 h-5" />
              <span>Export Transactions</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Settings className="w-5 h-5" />
              <span>Payment Settings</span>
            </button>
            <button className="w-full flex items-center gap-3 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-white transition-colors">
              <Calendar className="w-5 h-5" />
              <span>Schedule Report</span>
            </button>
          </div>

          {/* Payment Methods */}
          <div className="mt-6 pt-6 border-t border-gray-700">
            <h4 className="text-sm font-medium text-gray-300 mb-3">Accepted Methods</h4>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2 p-2 bg-gray-700/50 rounded text-xs text-gray-300">
                <div className="w-6 h-4 bg-blue-600 rounded-sm flex items-center justify-center text-white text-xs font-bold">V</div>
                Visa
              </div>
              <div className="flex items-center gap-2 p-2 bg-gray-700/50 rounded text-xs text-gray-300">
                <div className="w-6 h-4 bg-red-600 rounded-sm flex items-center justify-center text-white text-xs font-bold">M</div>
                Mastercard
              </div>
              <div className="flex items-center gap-2 p-2 bg-gray-700/50 rounded text-xs text-gray-300">
                <div className="w-6 h-4 bg-blue-500 rounded-sm flex items-center justify-center text-white text-xs font-bold">P</div>
                PayPal
              </div>
              <div className="flex items-center gap-2 p-2 bg-gray-700/50 rounded text-xs text-gray-300">
                <div className="w-6 h-4 bg-gray-800 rounded-sm flex items-center justify-center text-white text-xs font-bold">A</div>
                Apple Pay
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white">Recent Transactions</h3>
              <p className="text-sm text-gray-400">Latest payment activity</p>
            </div>
            <button className="text-blue-400 hover:text-blue-300 text-sm font-medium">
              View all
            </button>
          </div>
        </div>
        
        <div className="divide-y divide-gray-700">
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-10 h-10 bg-gray-700 rounded-full">
                    <span className="text-sm font-medium text-white">
                      {transaction.customer.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{transaction.customer}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <span>{transaction.id}</span>
                      <span>•</span>
                      <span>{transaction.method}</span>
                      <span>•</span>
                      <span>{transaction.time}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">${transaction.amount}</p>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(transaction.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                        {transaction.status}
                      </span>
                    </div>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-white transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Business Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Insights */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Performance Insights</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-green-400">Great Success Rate!</p>
                <p className="text-xs text-gray-300">Your payment success rate is 98.5%, above industry average</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <TrendingUp className="w-5 h-5 text-blue-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-400">Revenue Growth</p>
                <p className="text-xs text-gray-300">You're on track for 25% monthly growth</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-yellow-400">Optimization Tip</p>
                <p className="text-xs text-gray-300">Consider enabling Apple Pay to increase mobile conversions</p>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Methods Performance */}
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <h3 className="text-lg font-semibold text-white mb-4">Payment Methods</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-6 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">V</div>
                <span className="text-sm text-gray-300">Visa</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div className="w-3/4 h-full bg-blue-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-400">45%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-6 bg-red-600 rounded flex items-center justify-center text-white text-xs font-bold">M</div>
                <span className="text-sm text-gray-300">Mastercard</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div className="w-1/2 h-full bg-red-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-400">30%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-6 bg-blue-500 rounded flex items-center justify-center text-white text-xs font-bold">P</div>
                <span className="text-sm text-gray-300">PayPal</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div className="w-1/4 h-full bg-blue-400 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-400">15%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-6 bg-gray-800 rounded flex items-center justify-center text-white text-xs font-bold">A</div>
                <span className="text-sm text-gray-300">Apple Pay</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div className="w-1/6 h-full bg-gray-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-400">10%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );

  const renderTransactionsContent = () => (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex flex-1 gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
            />
          </div>
          <select className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-blue-500">
            <option value="all">All Status</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* All Transactions */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">All Transactions</h3>
          <p className="text-sm text-gray-400">Complete transaction history</p>
        </div>
        
        <div className="divide-y divide-gray-700">
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-full">
                    <span className="text-sm font-medium text-white">
                      {transaction.customer.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{transaction.customer}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <span>{transaction.id}</span>
                      <span>•</span>
                      <span>{transaction.method}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{transaction.time}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">${transaction.amount}</p>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(transaction.status)}
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(transaction.status)}`}>
                        {transaction.status}
                      </span>
                    </div>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-white transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCustomersContent = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-white">Customer Management</h3>
          <p className="text-sm text-gray-400">View and manage your customers</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <UserPlus className="w-4 h-4" />
          Add Customer
        </button>
      </div>

      {/* Customer Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Customers</p>
              <p className="text-2xl font-bold text-white">89</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Users className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active This Month</p>
              <p className="text-2xl font-bold text-white">67</p>
            </div>
            <div className="p-3 bg-green-500/20 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Avg Order Value</p>
              <p className="text-2xl font-bold text-white">$57.26</p>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <DollarSign className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Customer List */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h4 className="text-lg font-semibold text-white">Customer List</h4>
        </div>
        
        <div className="divide-y divide-gray-700">
          {customers.map((customer) => (
            <div key={customer.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-full">
                    <span className="text-sm font-medium text-white">
                      {customer.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{customer.name}</p>
                    <p className="text-xs text-gray-400">{customer.email}</p>
                    <p className="text-xs text-gray-500">Last order: {customer.lastOrder}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">${customer.totalSpent.toLocaleString()}</p>
                    <p className="text-xs text-gray-400">{customer.orders} orders</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    customer.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                  }`}>
                    {customer.status}
                  </span>
                  <button className="p-1 text-gray-400 hover:text-white transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPaymentLinksContent = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-white">Payment Links</h3>
          <p className="text-sm text-gray-400">Create and manage payment links</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
          <Plus className="w-4 h-4" />
          Create Link
        </button>
      </div>

      {/* Payment Links */}
      <div className="bg-gray-800 rounded-lg border border-gray-700">
        <div className="p-6 border-b border-gray-700">
          <h4 className="text-lg font-semibold text-white">Active Payment Links</h4>
        </div>
        
        <div className="divide-y divide-gray-700">
          {paymentLinks.map((link) => (
            <div key={link.id} className="p-6 hover:bg-gray-700/30 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-blue-500/20 rounded-lg">
                    <Link className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{link.title}</p>
                    <p className="text-xs text-gray-400">Created: {link.created}</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <span>{link.clicks} clicks</span>
                      <span>•</span>
                      <span>{link.conversions} conversions</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">${link.amount}</p>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      link.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {link.status}
                    </span>
                  </div>
                  <button className="p-1 text-gray-400 hover:text-white transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettingsContent = () => (
    <div className="space-y-6">
      {/* Business Settings */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Business Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Business Name</label>
            <input 
              type="text" 
              defaultValue="Alex's Coffee Shop"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Contact Email</label>
            <input 
              type="email" 
              defaultValue="alex@coffeeshop.com"
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Payment Settings */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Payment Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Accept Credit Cards</p>
              <p className="text-xs text-gray-400">Visa, Mastercard, American Express</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">PayPal</p>
              <p className="text-xs text-gray-400">Accept PayPal payments</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Apple Pay</p>
              <p className="text-xs text-gray-400">Accept Apple Pay payments</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold text-white mb-4">Notifications</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">Email Notifications</p>
              <p className="text-xs text-gray-400">Get notified of new payments</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">SMS Notifications</p>
              <p className="text-xs text-gray-400">Get SMS alerts for failed payments</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    const currentUrl = window.location.hash || '#merchant';
    
    if (currentUrl.includes('merchant-transactions')) {
      return renderTransactionsContent();
    } else if (currentUrl.includes('merchant-customers')) {
      return renderCustomersContent();
    } else if (currentUrl.includes('merchant-payments')) {
      return renderPaymentLinksContent();
    } else if (currentUrl.includes('merchant-settings')) {
      return renderSettingsContent();
    } else {
      return renderDashboardContent();
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Good morning, Alex! 👋</h1>
          <p className="text-gray-400">Here's what's happening with your business today</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500"
          >
            <option value="1d">Today</option>
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
          </select>
          <button className="p-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
          </button>
          <button className="p-2 bg-gray-800 border border-gray-700 rounded-lg text-gray-400 hover:text-white transition-colors">
            <HelpCircle className="w-5 h-5" />
          </button>
        </div>
      </div>

      {renderContent()}
    </div>
  );
};

export default MerchantDashboard;