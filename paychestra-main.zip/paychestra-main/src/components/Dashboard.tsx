import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, CreditCard, Globe, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import StatCard from './StatCard';
import Chart from './Chart';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Volume',
      value: '$2.4M',
      change: '+12.5%',
      trend: 'up' as const,
      icon: DollarSign,
      color: 'blue'
    },
    {
      title: 'Success Rate',
      value: '98.7%',
      change: '+2.1%',
      trend: 'up' as const,
      icon: CheckCircle,
      color: 'green'
    },
    {
      title: 'Transactions',
      value: '156,789',
      change: '+8.3%',
      trend: 'up' as const,
      icon: CreditCard,
      color: 'purple'
    },
    {
      title: 'Countries',
      value: '47',
      change: '+3',
      trend: 'up' as const,
      icon: Globe,
      color: 'indigo'
    },
  ];

  const recentTransactions = [
    { id: 'TX-12345', amount: '$1,234.56', status: 'completed', country: 'US', provider: 'Stripe' },
    { id: 'TX-12346', amount: '$987.65', status: 'pending', country: 'UK', provider: 'PayPal' },
    { id: 'TX-12347', amount: '$543.21', status: 'failed', country: 'DE', provider: 'Adyen' },
    { id: 'TX-12348', amount: '$2,345.67', status: 'completed', country: 'FR', provider: 'Stripe' },
    { id: 'TX-12349', amount: '$876.54', status: 'completed', country: 'CA', provider: 'Square' },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Chart
          title="Transaction Volume"
          subtitle="Last 30 days"
          data={[
            { name: 'Jan', value: 400000 },
            { name: 'Feb', value: 300000 },
            { name: 'Mar', value: 200000 },
            { name: 'Apr', value: 278000 },
            { name: 'May', value: 189000 },
            { name: 'Jun', value: 239000 },
            { name: 'Jul', value: 349000 },
          ]}
          type="area"
          color="#3B82F6"
        />
        
        <Chart
          title="Success Rate"
          subtitle="Provider comparison"
          data={[
            { name: 'Stripe', value: 98.7 },
            { name: 'PayPal', value: 97.2 },
            { name: 'Adyen', value: 98.9 },
            { name: 'Square', value: 96.8 },
          ]}
          type="bar"
          color="#10B981"
        />
      </div>

      {/* Recent Transactions */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Recent Transactions</h2>
          <button className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm font-medium">
            View all transactions
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-3 text-sm font-medium text-gray-600 dark:text-gray-300">ID</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Amount</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Status</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Country</th>
                <th className="text-left py-3 text-sm font-medium text-gray-600 dark:text-gray-300">Provider</th>
              </tr>
            </thead>
            <tbody>
              {recentTransactions.map((transaction) => (
                <tr key={transaction.id} className="border-b border-gray-100 dark:border-gray-700/50">
                  <td className="py-3 text-sm text-gray-600 dark:text-gray-300">{transaction.id}</td>
                  <td className="py-3 text-sm font-medium text-gray-900 dark:text-white">{transaction.amount}</td>
                  <td className="py-3">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(transaction.status)}
                      <span className="text-sm text-gray-600 dark:text-gray-300 capitalize">{transaction.status}</span>
                    </div>
                  </td>
                  <td className="py-3 text-sm text-gray-600 dark:text-gray-300">{transaction.country}</td>
                  <td className="py-3 text-sm text-gray-600 dark:text-gray-300">{transaction.provider}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;