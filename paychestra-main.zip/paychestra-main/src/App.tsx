import React, { useState } from 'react';
import { 
  CreditCard, 
  BarChart3, 
  Settings, 
  Shield, 
  Users, 
  Globe, 
  DollarSign,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  Menu,
  X,
  Home,
  Wallet,
  QrCode,
  FileText,
  ArrowLeft
} from 'lucide-react';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import Transactions from './components/Transactions';
import Providers from './components/Providers';
import Routing from './components/Routing';
import Fraud from './components/Fraud';
import Reconciliation from './components/Reconciliation';
import API from './components/API';
import MerchantDashboard from './components/MerchantDashboard';
import IndividualDashboard from './components/IndividualDashboard';
import MerchantRegistration from './components/MerchantRegistration';
import ThemeToggle from './components/ThemeToggle';
import { useTheme } from './contexts/ThemeContext';
import QRPayment from './components/QRPayment';
import Settlement from './components/Settlement';
import Invoices from './components/Invoices';
import Refunds from './components/Refunds';

function App() {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState('landing');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Listen for navigation events from landing page
  React.useEffect(() => {
    const handleNavigate = (event: CustomEvent) => {
      setActiveTab(event.detail);
    };
    
    window.addEventListener('navigate', handleNavigate as EventListener);
    return () => window.removeEventListener('navigate', handleNavigate as EventListener);
  }, []);

  const navigation = [
    { id: 'landing', name: 'Home', icon: Home },
    { id: 'dashboard', name: 'Platform Admin', icon: BarChart3 },
    { id: 'transactions', name: 'Transactions', icon: CreditCard },
    { id: 'providers', name: 'Providers', icon: Users },
    { id: 'routing', name: 'Routing', icon: Globe },
    { id: 'fraud', name: 'Fraud Detection', icon: Shield },
    { id: 'reconciliation', name: 'Reconciliation', icon: DollarSign },
    { id: 'api', name: 'API', icon: Settings },
  ];

  const individualNavigation = [
    { id: 'landing', name: 'Home', icon: Home },
    { id: 'individual', name: 'Dashboard', icon: BarChart3 },
    { id: 'individual-transactions', name: 'My Transactions', icon: CreditCard },
    { id: 'individual-cards', name: 'Payment Methods', icon: Wallet },
    { id: 'individual-settings', name: 'Settings', icon: Settings },
  ];

  const merchantNavigation = [
    { id: 'landing', name: 'Home', icon: Home },
    { id: 'merchant', name: 'Dashboard', icon: BarChart3 },
    { id: 'merchant-transactions', name: 'Transactions', icon: CreditCard },
    { id: 'merchant-customers', name: 'Customers', icon: Users },
    { id: 'merchant-invoices', name: 'Invoices', icon: FileText },
    { id: 'merchant-payments', name: 'Payment Links', icon: Globe },
    { id: 'merchant-qr', name: 'QR Payments', icon: QrCode },
    { id: 'merchant-settlement', name: 'Settlement', icon: DollarSign },
    { id: 'merchant-refunds', name: 'Refunds', icon: ArrowLeft },
    { id: 'merchant-settings', name: 'Settings', icon: Settings },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'landing':
        return <LandingPage />;
      case 'merchant-registration':
        return <MerchantRegistration />;
      case 'individual':
      case 'individual-transactions':
      case 'individual-cards':
      case 'individual-settings':
        return <IndividualDashboard />;
      case 'merchant-qr':
        return <QRPayment />;
      case 'merchant-settlement':
        return <Settlement />;
      case 'merchant-invoices':
        return <Invoices />;
      case 'merchant-refunds':
        return <Refunds />;
      case 'merchant':
      case 'merchant-transactions':
      case 'merchant-customers':
      case 'merchant-payments':
      case 'merchant-settings':
        return <MerchantDashboard />;
      case 'dashboard':
        return <Dashboard />;
      case 'transactions':
        return <Transactions />;
      case 'providers':
        return <Providers />;
      case 'routing':
        return <Routing />;
      case 'fraud':
        return <Fraud />;
      case 'reconciliation':
        return <Reconciliation />;
      case 'api':
        return <API />;
      default:
        return <LandingPage />;
    }
  };

  const getCurrentNavigation = () => {
    if (activeTab.startsWith('individual')) return individualNavigation;
    if (activeTab.startsWith('merchant')) return merchantNavigation;
    return navigation;
  };

  const getCurrentTitle = () => {
    const currentNav = getCurrentNavigation();
    const currentItem = currentNav.find(item => item.id === activeTab);
    return currentItem?.name || 'Dashboard';
  };

  // If on landing page, render without sidebar
  if (activeTab === 'landing') {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        {/* Landing page header */}
        <header className="absolute top-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-800">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-gray-900 dark:text-white">PayOrchestra</span>
              </div>
              <div className="flex items-center gap-3">
                <ThemeToggle />
                <button 
                  onClick={() => setActiveTab('dashboard')}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-medium transition-colors"
                >
                  Enter Dashboard
                </button>
              </div>
            </div>
          </div>
        </header>
        <LandingPage />
      </div>
    );
  }

  const currentNavigation = getCurrentNavigation();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900 dark:text-white">PayOrchestra</span>
          </div>
          <button 
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <nav className="mt-8 px-4">
          {currentNavigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                  activeTab === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Main content */}
      <div className="lg:ml-64">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between h-16 px-6">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white capitalize">
              {getCurrentTitle()}
            </h1>
            
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600 dark:text-gray-300">System Online</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;